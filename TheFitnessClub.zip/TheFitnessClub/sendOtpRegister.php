<?php
// Function to generate OTP
function generateOTP() {
    return rand(100000, 999999);
}

// Function to send email
function sendEmail($to, $otp) {
    $subject = "Email Verification OTP";
    $message = "Your OTP for Email Verification is: " . $otp;
    $headers = "From: info@thefitnessclub.in\r\n";
    return mail($to, $subject, $message, $headers);
}

// Function to check if email exists in the database
function isEmailExists($email, $conn) {
    $sql = "SELECT COUNT(*) AS count FROM client_info WHERE email = '$email'";
    $result = $conn->query($sql);
    $row = $result->fetch_assoc();
    return $row['count'] > 0;
}

// Main logic
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get email address from form submission
    $email = strtolower($_POST["email"]);
    
    // Database connection parameters
    require "connect.php";
    
    // Check if email exists in the database
    if (isEmailExists($email, $conn)) {
        // Redirect to login page
        header("Location: login.php?error=emailAlreadyExists");
        exit();
    } else {
        // Generate OTP
        $otp = generateOTP();
        
        // Send OTP via email
        if (sendEmail($email, $otp)) {
            // Store OTP and current time in session
            session_start();
            $_SESSION["otp"] = $otp;
            $_SESSION["otp_time"] = time();
            $_SESSION["email"] = $email;
            
            // Redirect to verification page
            header("Location: enterOtpRegister.php");
            exit();
        } else {
            header("Location: enterEmailRegister.php?update=emailsendfailed");
            exit();
        }
    }
    $conn->close(); // Close database connection
}
?>
