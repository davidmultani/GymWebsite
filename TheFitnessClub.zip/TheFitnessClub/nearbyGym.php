<?php 
require "header.php";
?>
<section class="breadcrumb-section set-bg" data-setbg="img/breadcrumb-bg.jpg">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 text-center">
                    <div class="breadcrumb-text">
                        <h2>Nearby Gyms</h2>
                        <div class="bt-option">
                            <a href="./index.html">Home</a>
                            <span>Nearby Gyms</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
</section>
<section class="breadcrumb-section set-bg" id="map">
</section>
<section class="team-section team-page spad">
        <div class="container">
            <center>
                <div class="col-lg-6 col-sm-4">
                    <div class="leave-comment">
                    <form method="post">
                        <input type="text" id="location" name="location" class="m-0 mt-0">
                        <button type="submit" class="primary-btn btn-normal appoinment-btn m-0">Find Gyms</button>
                    </form>
                    </div>
                </div>
            </center>
        </div>
 </section>
         <script>
        // Function to initialize the map
        function initMap() {
            // Create a map object and set its properties
            const map = new google.maps.Map(document.getElementById("map"), {
                zoom: 14, // Zoom level
                center: { lat: -34.397, lng: 150.644 }, // Default center (Sydney, Australia)
            });

            // Create an autocomplete object for the input field
            const input = document.getElementById("location");
            const autocomplete = new google.maps.places.Autocomplete(input);

            // Set the bounds to restrict suggestions to the map area
            autocomplete.bindTo("bounds", map);

            // Get the user's location
            navigator.geolocation.getCurrentPosition(position => {
                const userLocation = {
                    lat: position.coords.latitude,
                    lng: position.coords.longitude
                };
                // Set the map center to the user's location
                map.setCenter(userLocation);
            });

            // Retrieve nearby gym locations when the form is submitted
            document.querySelector('form').addEventListener('submit', function(e) {
                e.preventDefault();
                const location = input.value;
                const request = {
                    query: location,
                    fields: ['geometry']
                };
                const service = new google.maps.places.PlacesService(map);
                service.findPlaceFromQuery(request, (results, status) => {
                    if (status === google.maps.places.PlacesServiceStatus.OK && results.length > 0) {
                        const place = results[0];
                        const userLocation = place.geometry.location;
                        map.setCenter(userLocation);

                        // Retrieve nearby gym locations
                        const request = {
                            location: userLocation,
                            radius: '5000',
                            type: ['gym']
                        };
                        const service = new google.maps.places.PlacesService(map);
                        service.nearbySearch(request, (results, status) => {
                            if (status === google.maps.places.PlacesServiceStatus.OK) {
                                for (let i = 0; i < results.length; i++) {
                                    const place = results[i];
                                    // Create a marker for each nearby gym
                                    const marker = new google.maps.Marker({
                                        position: place.geometry.location,
                                        map: map,
                                        title: place.name
                                    });
                                    // Create an info window for each marker showing the gym's name and address
                                    const infoWindow = new google.maps.InfoWindow({
                                        content: `<strong>${place.name}</strong><br>${place.vicinity}`
                                    });
                                    // Add click listener to show info window when marker is clicked
                                    marker.addListener('click', () => {
                                        infoWindow.open(map, marker);
                                    });
                                }
                            }
                        });
                    }
                });
            });
        }
    </script>
    <!-- Include the Google Maps JavaScript API -->
    <script src="https://maps.googleapis.com/maps/api/js?key='YourApiKey'&libraries=places&callback=initMap" async defer></script>
</div>
<?php 
require "footer.php";
?>