<?php
require "header.php"
?>    
<!-- Breadcrumb Section Begin -->
    <section class="breadcrumb-section set-bg" data-setbg="img/breadcrumb-bg.jpg">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 text-center">
                    <div class="breadcrumb-text">
                        <h2>Login</h2>
                        <div class="bt-option">
                            <span>Enter your Credentials</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Breadcrumb Section End -->

    <!-- Login Section Begin -->
    <section class="team-section team-page spad">
        <div class="container">
            <center>
                <div class="col-lg-6 col-sm-4">
                    <div class="leave-comment">

                        <?php
                        // Function to generate a random math equation
                        function generateMathEquation() {
                            $num1 = rand(1, 10);
                            $num2 = rand(1, 10);
                            $operator = ['+', '-'][array_rand(['+', '-'])]; // Random operator
                            $answer = eval("return $num1 $operator $num2;");
                            $_SESSION['answer'] = $answer;
                            return "$num1 $operator $num2";
                        }

                        // Check if an error parameter is present in the URL
                        if (isset($_GET['error'])) {
                            if ($_GET['error'] === 'Usernotfound') {
                                echo "<p style='color: red; font-size:15px;'>Username Not Found.</p>";
                            }
                            elseif ($_GET['error'] === 'passwordincorrect') {
                                echo "<p style='color: red; font-size:15px;'>Incorrect Password</p>";
                            }
                            elseif ($_GET['error'] === 'membershipexpired') {
                                echo "<p style='color: red; font-size:15px;'>Membership Expired</p>";
                            }
                            elseif ($_GET['error'] === 'emailAlreadyExists') {
                                echo "<p style='color: red; font-size:15px;'>Email Already Exists.</p>";
                            }
                            else {
                                echo "<p style='color: red; font-size:15px;'>An unknown error occurred.</p>";
                            }
                        }
                        
                        if(isset($_GET['Registration_Successful']))
                        {
                           // Display Registration Successful message
                           echo "<p style='color: green; font-size: 15px;'>Registration Successful</p>"; 
                        }
                        if(isset($_GET['resetsuccess']))
                        {
                           // Display Registration Successful message
                           echo "<p style='color: green; font-size: 15px;'>Password Reset Successful</p>"; 
                        }
                        ?>
                        
                        <form action="./login_form.php" method="post" onsubmit="return validateForm()">
                            <input type="text" placeholder="Username" name="username" >
                            <input type="password" placeholder="Password" name="password" >
                            <!-- Math equation challenge -->
                            <p><?php echo generateMathEquation(); ?> = ?</p>
                            <input type="number" placeholder="Enter answer" name="answer" required>
                            
                            <button type="submit" class="primary-btn btn-normal appoinment-btn">Login</button>
                        </form>
                    </div>
                    <p id="error-message" class="error-message"></p>
                    <div class="p-2">
                         <a href="enterEmail.php">Forgot Password /</a>
                        <a href="enterEmailRegister.php">Create Account</a>
                    </div>
                </div>
            </center>
        </div>
    </section>
    <!-- shake on login fail script -->
    <script>
        
    </script>
    <!-- Team Section End -->
    <?php
	require "footer.php"
	?>