<?php
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Check if OTP and email are set in the session
    if (isset($_SESSION["otp"]) && isset($_SESSION["email"])) {
        $otp_from_user = $_POST["otp"];
        $stored_otp = $_SESSION["otp"];
        $email = $_SESSION["email"];
        
        // Verify OTP
        if ($otp_from_user == $stored_otp) {
            // Check if OTP is expired (valid for 5 minutes)
            $otp_time = $_SESSION["otp_time"];
            if (time() - $otp_time <= 300) { // 300 seconds = 5 minutes
                // Your OTP is valid
                // Perform necessary actions here, e.g., mark email as verified in the database
                header("Location: enterNewPassword.php");
                
                // Clear session variables
                unset($_SESSION["otp"]);
                unset($_SESSION["otp_time"]);
            } else {
                // OTP expired
                header("Location: enterEmail.php?update=otpexpired");
            }
        } else {
            // Invalid OTP
            header("Location: enterOtp.php?update=invalidotp");
        }
    } else {
        // Session data not set, redirect to enterEmail.php
        header("Location: enterEmail.php?update=sessionexpired");
        exit();
    }
} else {
    // Invalid request method
    header("Location: enterEmail.php");
    exit();
}
?>
