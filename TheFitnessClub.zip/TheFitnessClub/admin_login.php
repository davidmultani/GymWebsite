<?php
require "header.php"
?>    
<!-- Breadcrumb Section Begin -->
    <section class="breadcrumb-section set-bg" data-setbg="img/breadcrumb-bg.jpg">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 text-center">
                    <div class="breadcrumb-text">
                        <h2>Admin Login</h2>
                        <div class="bt-option">
                            <span>Enter your Credentials</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Breadcrumb Section End -->

    <!-- Login Section Begin -->
    <section class="team-section team-page spad">
        <div class="container">
            <center>
                <div class="col-lg-6 col-sm-4">
                    <div class="leave-comment">

                        <?php
                        // Check if an error parameter is present in the URL
                        if (isset($_GET['error'])) {
                            // Check the value of the error parameter
                            if ($_GET['error'] === 'incorrect') {
                                // Display error message for incorrect username or password
                                echo "<p style='color: red; font-size:20px;'>Username or password is incorrect.</p>";
                            }
                        }
                        if(isset($_GET['Registration_Successful']))
                        {
                           // Display Registration Successful message
                           echo "<p style='color: green; font-size: 20px;'>Registration Successful</p>"; 
                        }
                        ?>
                        
                        <form action="./admin/login_form.php" method="post" onsubmit="return validateForm()">
                            <input type="text" placeholder="Username" name="username">
                            <input type="password" placeholder="Password" name="password">
                            
                            <button type="submit">Login</button>
                        </form>
                    </div>
                    <p id="error-message" class="error-message"></p>
                    <div class="p-2">
                        <a href="admin_register.php">Dont have the account register here.</a>
                    </div>
                </div>
            </center>
        </div>
    </section>
    <!-- shake on login fail script -->
    <script>
        
    </script>
    <!-- Team Section End -->
    <?php
	require "footer.php"
	?>