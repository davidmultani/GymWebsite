<?php
require "connect.php";

// retreive contact form data from POST request

$name = $_POST['name'];
$email = $_POST['email'];
$phone_no = $_POST['phone_no'];
$comment = $_POST['comment'];

// Sanitize inputs before using in SQL query (to prevent SQL injection)
$name = mysqli_real_escape_string($conn, $name);
$email = mysqli_real_escape_string($conn, $email);
$phone_no = mysqli_real_escape_string($conn, $phone_no);
$comment = mysqli_real_escape_string($conn, $comment);

// SQL query to insert new user
$sql = "INSERT INTO contact_form (name,email, phone_no, comment)  VALUES ('$name','$email', '$phone_no', '$comment')";

// Execute query
$result = $conn->query($sql);

if ($result === TRUE) {
    header("Location: contact.php?update=success");
    exit();
} else {
    header("Location: contact.php?update=fail");
    exit(); // Terminate script to prevent further execution
}

$conn->close();
?>