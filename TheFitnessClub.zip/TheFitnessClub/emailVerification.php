<?php
require "header.php"
?>    
<!-- Breadcrumb Section Begin -->
    <section class="breadcrumb-section set-bg" data-setbg="img/breadcrumb-bg.jpg">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 text-center">
                    <div class="breadcrumb-text">
                        <h2>Login</h2>
                        <div class="bt-option">
                            <span>Enter your Credentials</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Breadcrumb Section End -->

    <!-- Login Section Begin -->
    <section class="team-section team-page spad">
        <div class="container">
            <center>
                <div class="col-lg-6 col-sm-4">
                    <div class="leave-comment">

                        <?php
                        // Check if an error parameter is present in the URL
                        if (isset($_GET['error'])) {
                            if ($_GET['error'] === 'Usernotfound') {
                                echo "<p style='color: red; font-size:15px;'>Username Not Found.</p>";
                            }
                            elseif ($_GET['error'] === 'passwordincorrect') {
                                echo "<p style='color: red; font-size:15px;'>Incorrect Password</p>";
                            }
                            elseif ($_GET['error'] === 'membershipexpired') {
                                echo "<p style='color: red; font-size:15px;'>Membership Expired</p>";
                            }
                            else {
                                echo "<p style='color: red; font-size:115px;'>An unknown error occurred.</p>";
                            }
                        }
                        
                        if(isset($_GET['Registration_Successful']))
                        {
                           // Display Registration Successful message
                           echo "<p style='color: green; font-size: 20px;'>Registration Successful</p>"; 
                        }
                        ?>
                        
                        <form action="./login_form.php" method="post" onsubmit="return validateForm()">
                            <input type="email" placeholder="Email" name="Email" value="<?php echo $row['email'] ?>" disabled >
                            <input type="number" placeholder="Enter the otp" name="otp" >
                            
                            <button type="submit" class="primary-btn btn-normal appoinment-btn">Login</button>
                        </form>
                    </div>
                    <p id="error-message" class="error-message"></p>
                </div>
            </center>
        </div>
    </section>
    <!-- shake on login fail script -->
    <script>
        
    </script>
    <!-- Team Section End -->
    <?php
	require "footer.php"
	?>