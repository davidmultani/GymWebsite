<?php
require "connect.php";

// Retrieve registration data from POST request
$id = $_GET['id'];
$name = $_POST['name'];
$weight = $_POST['weight'];
$height = $_POST['height'];
$dob = $_POST['dob'];
$sex = $_POST['sex'];
$level = $_POST['level'];
$activity_level = $_POST['activity_level'];
$target = $_POST['target'];
$password = $_POST['password'];
$encrypt_password = password_hash($password, PASSWORD_DEFAULT);

// Validation for password
if (empty($name)) {
    header("Location: ./login/edit_user.php?id=$id&error=" . urlencode("Name is required"));
    exit();
}
$min_length = 8;
if (strlen($password) < $min_length || !preg_match('/[A-Z]/', $password) || !preg_match('/[a-z]/', $password) || !preg_match('/[0-9]/', $password) || !preg_match('/[^a-zA-Z0-9]/', $password)) {
    header("Location: ./login/edit_user.php?error=" . urlencode("Password must be at least 8 characters long and contain at least one uppercase letter, one lowercase letter, one number, and one special character"));
    exit();
}


// Check if file is uploaded successfully
if ($_FILES['profile_picture']['error'] === UPLOAD_ERR_OK) {
    // Retrieve information about the uploaded file
    $fileTmpPath = $_FILES['profile_picture']['tmp_name'];
    $fileName = $_FILES['profile_picture']['name'];
    $fileSize = $_FILES['profile_picture']['size'];
    $fileType = $_FILES['profile_picture']['type'];
    
    // Specify the folder where you want to store the uploaded files
    $uploadDirectory = './img/users_pictures/';

    // Move the uploaded file to the desired destination
    $destPath = $uploadDirectory . $fileName;
    if (!move_uploaded_file($fileTmpPath, $destPath)) {
        // File move failed, handle the error accordingly
        header("Location: ./login/edit_user.php?error=" . urlencode("Failed to move uploaded file"));
        exit();
    }
} else {
    // File upload failed, handle the error accordingly
    header("Location: ./login/edit_user.php?error=" . urlencode("File upload failed: " . $_FILES['profile_picture']['error']));
    exit();
}

// Sanitize inputs before using in SQL query (to prevent SQL injection)
$name = mysqli_real_escape_string($conn, $name);
$sex = mysqli_real_escape_string($conn, $sex);
$weight = mysqli_real_escape_string($conn, $weight);
$level = mysqli_real_escape_string($conn, $level);
$encrypt_password = mysqli_real_escape_string($conn, $encrypt_password);
$destPath = mysqli_real_escape_string($conn, $destPath);
$dob = mysqli_real_escape_string($conn, $dob);
$height = mysqli_real_escape_string($conn, $height);
$target = mysqli_real_escape_string($conn, $target);
$activity_level = mysqli_real_escape_string($conn, $activity_level);

// SQL query to insert new user
$sql = "UPDATE client_info SET name='$name', sex='$sex', weight='$weight', level='$level', password='$encrypt_password', 
        photo='$destPath',dob='$dob', height='$height', target='$target', activity_level='$activity_level' WHERE client_no=$id";

// Execute query
$result = $conn->query($sql);

if ($result === TRUE) {
    // Registration successful, redirect to login page or wherever you want
    header("Location: ./login/index.php?");
    exit();
} else {
    // Registration failed, redirect back to registration page with error message
    header("Location: ./login/edit_user.php?error=" . urlencode("Registration failed: " . $conn->error));
    exit();
}

$conn->close();
?>
