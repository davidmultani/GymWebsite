<?php
require "header.php";
$plan = $_GET['plan'];
?>    
<!-- Breadcrumb Section Begin -->
    <section class="breadcrumb-section set-bg" data-setbg="img/breadcrumb-bg.jpg">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 text-center">
                    <div class="breadcrumb-text">
                        <h2>Register</h2>
                        <div class="bt-option">
                            <span>Enter your Credentials</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Breadcrumb Section End -->

    <!-- Team Section Begin -->
    <section class="team-section team-page spad">
        <div class="container">
            <center>
                <div class="col-lg-6 col-sm-4 mx-auto">
                    <div class="leave-comment">
                        <?php
                        // Check for error message from registration process
                        if (isset($_GET['error'])) {
                            echo "<p style='color: red;' class='error-message'>Registration failed: " . $_GET['error'] . "</p>";
                        }
                        ?>
                        <form action="./registration_form.php" method="post" enctype="multipart/form-data" >
                            <input type="text" name="name" placeholder="Name" required >
                            <input type="email" name="email" placeholder="Email" value="<?php echo $_SESSION['email']?>" disabled >
                            <input type="tel" name="phone_no" placeholder="Phone Number" required >
                            <div class="grid-row">
                                <input type="number" name="weight" placeholder="Weight" required >
                                <input type="text" name="height" placeholder="Height" max="220" required >
                                <input type="date" name="dob" placeholder="Date Of Birth" max="<?php echo date('Y-m-d'); ?>" required class="mb-2">
                                <select name="sex" required class="mb-2">
                                    <option value="" disabled selected>Select Sex</option>
                                    <option value="male">Male</option>
                                    <option value="female">Female</option>
                                </select>
                                <select name="level" required >
                                    <option value="" disabled selected>Select level</option>
                                    <option value="Beginner" >Beginner</option>
                                    <option value="Intermediate" >Intermediate</option>
                                    <option value="Advance" >Advance</option>
                                </select>
                                <select name="membership" required >
                                    <option value="" disabled selected>Select plan</option>
                                    <option value="1" <?php if ($plan === "1") echo "selected"; ?>>1 Month</option>
                                    <option value="3" >3 Month</option>
                                    <option value="6" <?php if ($plan === "6") echo "selected"; ?>>6 Month</option>
                                    <option value="12" <?php if ($plan === "12") echo "selected"; ?>>12 Month</option>
                                </select>
                                <select name="activity_level" required class="mt-2">
                                    <option value="" disabled selected>Select Activity Level</option>
                                    <option value="Sedentary" >Sedentary</option>
                                    <option value="Lightly Active" >Lightly Active</option>
                                    <option value="Moderately Active" >Moderately Active</option>
                                    <option value="Very Active" >Very Active</option>
                                    <option value="Extra Active" >Extra Active</option>
                                </select>
                                <select name="target" required >
                                    <option value="" disabled selected>Select Target</option>
                                    <option value="Fat Loss" >Fat Loss</option>
                                    <option value="Muscle Gain" >Muscle Gain</option>
                                    <option value="Get Fit" >Get Fit</option>
                                </select>
                            </div>
                            <input type="text" name="username" placeholder="Username" required class="mt-1">
                            <input type="password" name="password" placeholder="Password" required class="mt-1" >
                            <input type="file" name="profile_picture" required />
                            <input type="submit" value="Register">
                        </form>
                    </div>
                </div>
            </center>
        </div>
    </section>
    <!-- Team Section End -->
    <?php
	require "footer.php"
	?>