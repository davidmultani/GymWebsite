<?php
require "connect.php";
session_start();

// Retrieve registration data from POST request
$name = $_POST['name'];
$email = strtolower($_SESSION['email']);
$phone_no = $_POST['phone_no'];
$sex = $_POST['sex'];
$weight = $_POST['weight'];
$level = $_POST['level'];
$username = $_POST['username'];
$password = $_POST['password'];
$membership = $_POST['membership'];
$dob = $_POST['dob'];
$height = $_POST['height'];
$activity_level = $_POST['activity_level'];
$target = $_POST['target'];
$encrypt_password = password_hash($password, PASSWORD_DEFAULT);

// Validate email
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    handleError("Invalid email format");
}

// Validate phone number
if (!preg_match('/^\d{10}$/', $phone_no)) {
    handleError("Invalid phone number format");
}

// Validate username
if (!preg_match('/^[a-zA-Z0-9_]+$/', $username)) {
    handleError("Username can only contain letters, numbers, and underscores");
}

// Validate password
$min_length = 8;
if (strlen($password) < $min_length || !preg_match('/[A-Z]/', $password) || !preg_match('/[a-z]/', $password) || !preg_match('/[0-9]/', $password) || !preg_match('/[^a-zA-Z0-9]/', $password)) {
    handleError("Password must be at least 8 characters long and contain at least one uppercase letter, one lowercase letter, one number, and one special character");
}

// Check if email already exists
$sql_check_email = "SELECT * FROM client_info WHERE email=?";
$stmt_check_email = $conn->prepare($sql_check_email);
$stmt_check_email->bind_param("s", $email);
$stmt_check_email->execute();
$result_check_email = $stmt_check_email->get_result();

if ($result_check_email->num_rows > 0) {
    handleError("Email already exists");
}

// Check if Username already exists
$sql_check_username = "SELECT * FROM client_info WHERE username=?";
$stmt_check_username = $conn->prepare($sql_check_username);
$stmt_check_username->bind_param("s", $username);
$stmt_check_username->execute();
$result_check_username = $stmt_check_username->get_result();

if ($result_check_username->num_rows > 0) {
    handleError("Username already exists");
}

// Check if file is uploaded successfully
if ($_FILES['profile_picture']['error'] !== UPLOAD_ERR_OK) {
    handleError("File upload failed: " . $_FILES['profile_picture']['error']);
}

// Move the uploaded file to the desired destination
$uploadDirectory = './img/users_pictures/';
$fileTmpPath = $_FILES['profile_picture']['tmp_name'];
$fileName = $_FILES['profile_picture']['name'];
$destPath = $uploadDirectory . $fileName;
if (!move_uploaded_file($fileTmpPath, $destPath)) {
    handleError("Failed to move uploaded file");
}

// Calculate the expiration date based on membership value
$currentDate = date('Y-m-d');
$membershipMonths = intval($_POST['membership']);
$expirationDate = date('Y-m-d', strtotime("+$membershipMonths months", strtotime($currentDate)));

// Prepare and execute SQL query to insert new user with membership details
$sql_insert_user = "INSERT INTO client_info (name, email, phone_no, sex, weight, level, username, password, photo, membership_start_date, membership_end_date, dob, height, activity_level, target) 
                      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
$stmt_insert_user = $conn->prepare($sql_insert_user);
$stmt_insert_user->bind_param("sssssssssssssss", $name, $email, $phone_no, $sex, $weight, $level, $username, $encrypt_password, $destPath, $currentDate, $expirationDate, $dob, $height, $activity_level, $target);

if ($stmt_insert_user->execute()) {
    // Registration successful, redirect to login page or wherever you want
    header("Location: login.php?Registration_Successful");
    exit();
} else {
    // Registration failed, redirect back to registration page with error message
    handleError("Registration failed: " . $stmt_insert_user->error);
}

$stmt_insert_user->close();
$conn->close();

function handleError($errorMessage) {
    header("Location: register.php?error=" . urlencode($errorMessage));
    exit();
}
?>
