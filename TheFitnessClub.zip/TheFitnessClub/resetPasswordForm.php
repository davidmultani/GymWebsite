<?php 
require "connect.php";
session_start();

$email = $_SESSION['email'];
$newPassword = $_POST['password'];
$reEnterPassword = $_POST['reEnterPassword'];

// Check if passwords match
if ($newPassword != $reEnterPassword) {
    header("Location: enterNewPassword.php?error=" . urlencode("Passwords do not match"));   
    exit();
}

// Validate password strength
$min_length = 8;
if (
    strlen($newPassword) < $min_length ||
    !preg_match('/[A-Z]/', $newPassword) ||
    !preg_match('/[a-z]/', $newPassword) ||
    !preg_match('/[0-9]/', $newPassword) ||
    !preg_match('/[^a-zA-Z0-9]/', $newPassword)
) {
    header("Location: enterNewPassword.php?error=" . urlencode("Password must be at least 8 characters long and contain at least one uppercase letter, one lowercase letter, one number, and one special character"));
    exit();
}

// Hash the new password
$encrypt_password = password_hash($newPassword, PASSWORD_DEFAULT);

// Update password in the database
$sql = "UPDATE client_info SET password='$encrypt_password' WHERE email='$email'";
$result = $conn->query($sql);

// Check if the update was successful
if ($result === TRUE) {
    header("Location: login.php?resetsuccess");
    exit();
} else {
    header("Location: login.php?error=" . urlencode("Password reset failed: " . $conn->error));
    exit();
}

// Close database connection
$conn->close();
?>
