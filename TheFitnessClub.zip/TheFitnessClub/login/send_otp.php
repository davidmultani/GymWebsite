<?php
// Function to generate OTP
function generateOTP() {
    return rand(100000, 999999);
}

// Function to send email
function sendEmail($to, $otp) {
    $subject = "Email Verification OTP";
    $message = "Your OTP for email verification is: " . $otp;
    $headers = "From: info@thefitnessclub.in\r\n";
    return mail($to, $subject, $message, $headers);
}

// Main logic
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get email address from form submission
    $email = $_POST["email"];
    
    // Generate OTP
    $otp = generateOTP();
    
    // Send OTP via email
    if (sendEmail($email, $otp)) {
        // Store OTP and current time in session
        session_start();
        $_SESSION["otp"] = $otp;
        $_SESSION["otp_time"] = time();
        $_SESSION["email"] = $email;
        
        // Redirect to verification page
        header("Location: verify_otp.php");
        exit();
    } else {
        echo "Failed to send email. Please try again.";
    }
}
?>