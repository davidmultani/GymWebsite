<?php
require "header.php";
    ?>
<!-- Breadcrumb Section Begin -->
<section class="breadcrumb-section set-bg" data-setbg="img/breadcrumb-bg.jpg">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 text-center">
                <div class="breadcrumb-text">
                    <h2>Day - <?php echo $days_passed ?></h2>
                    <h3 style="color:#f36100"><?php echo $currentDay ?></h3>

                </div>
            </div>
        </div>
    </div>
</section>
<!-- Breadcrumb Section End -->

<!-- Team Section Begin -->
<section class="team-section team-page spad">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="team-title">
                        <div class="section-title">
                            <h2>Workout Plan</h2>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
            <?php
            start:
            if($level==="Intermediate"){
                goto Intermediate;
            }
            if ($level === "Beginner")
            {
            if($days_passed>=1 && $days_passed<=30)
            {
                {
                        if ($currentDay == 'Sunday') {
                            ?>
                                 <h3 style="text-align:center; color:white;">Rest Day</h3>   
                            <?php    
                        } elseif ($currentDay == 'Monday') {
                                $muscleGroups = array("chest", "shoulder", "triceps", "biceps", "back", "legs");
                                foreach ($muscleGroups as $muscle) {
                                    $sql = "SELECT * FROM $muscle ORDER BY RAND() LIMIT 1";
                                    $result = $conn->query($sql);
                                    if ($result->num_rows > 0) 
                                    {
                                        // Output data of each user
                                        foreach($result as $row) {
                                    ?>  
                                        <div class="col-lg-4 col-sm-6">
                                            <div class="ts-item set-bg" data-setbg="<?php echo $row['photo']; ?>">
                                                <div class="ts_text">
                                                    <h4><?php echo $row['name']; ?></h4>
                                                    <div class="tt_social">
                                                        <p><?php echo $row['submuscle']; ?></p>
                                                        <p>3 Sets x 12 Reps</p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    <?php
                                        }
                                    }      
                                }   
                        
                        } elseif ($currentDay == 'Tuesday') {
                                $sql = "SELECT * FROM cardio ORDER BY RAND() LIMIT 1";
                                    $result = $conn->query($sql);
                                    if ($result->num_rows > 0) 
                                    {
                                        // Output data of each user
                                        foreach($result as $row) {
                                    ?>
                                        <div class="col-lg-4 col-sm-6">
                                            <div class="ts-item set-bg" data-setbg="<?php echo $row['photo']; ?>">
                                                <div class="ts_text">
                                                    <h4><?php echo $row['name']; ?></h4>
                                                    <div class="tt_social">
                                                        <p><?php echo $row['submuscle']; ?></p>
                                                        <p>3 Sets x 12 Reps</p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    <?php
                                        }
                                    }
                            
                        } elseif ($currentDay == 'Wednesday') {
                        ?>
                        <div class="row">
                        <div class="col-lg-12">
                            <div class="team-title">
                                    <div class="section-title">
                                        <h3 style="text-align:center; color:white;">Light Activity</h3>
                                    </div>
                            </div>
                        </div>
                        </div>
                        <?php
                            
                        } elseif ($currentDay == 'Thursday') {
                             $muscleGroups = array("chest", "shoulder", "triceps", "biceps", "back", "legs");
                                foreach ($muscleGroups as $muscle) {
                                    $sql = "SELECT * FROM $muscle ORDER BY RAND() LIMIT 1";
                                    $result = $conn->query($sql);
                                    if ($result->num_rows > 0) 
                                    {
                                        // Output data of each user
                                        foreach($result as $row) {
                                    ?>
                                        <div class="col-lg-4 col-sm-6">
                                            <div class="ts-item set-bg" data-setbg="<?php echo $row['photo']; ?>">
                                                <div class="ts_text">
                                                    <h4><?php echo $row['name']; ?></h4>
                                                    <div class="tt_social">
                                                        <p><?php echo $row['submuscle']; ?></p>
                                                        <p>3 Sets x 12 Reps</p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    <?php
                                        }
                                    }      
                                } 

                        } elseif ($currentDay == 'Friday') {
                                $sql = "SELECT * FROM cardio ORDER BY RAND() LIMIT 1";
                                    $result = $conn->query($sql);
                                    if ($result->num_rows > 0) 
                                    {
                                        // Output data of each user
                                        foreach($result as $row) {
                                    ?>
                                        <div class="col-lg-4 col-sm-6">
                                            <div class="ts-item set-bg" data-setbg="<?php echo $row['photo']; ?>">
                                                <div class="ts_text">
                                                    <h4><?php echo $row['name']; ?></h4>
                                                    <div class="tt_social">
                                                        <p><?php echo $row['submuscle']; ?></p>
                                                        <p>3 Sets x 12 Reps</p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    <?php
                                        }
                                    }
                            
                        } else {
                            ?>
                            <div class="row">
                            <div class="col-lg-12">
                            <div class="team-title">
                                    <div class="section-title">
                                        <h3 style="text-align:center; color:white;">Light Activity</h3>
                                    </div>
                            </div>
                            </div>
                        </div>
                        <?php      
                        }
                }
            }
            if($days_passed>30 && $days_passed<=365)
            {
                Intermediate:
                {
                        if ($currentDay == 'Sunday') {
                            ?>
                                 <h3 style="text-align:center; color:white;">Rest Day</h3>   
                            <?php    
                        } elseif ($currentDay == 'Monday') {
                                $muscleGroups = array("chest", "shoulder", "triceps");
                                foreach ($muscleGroups as $muscle) {
                                    $sql = "SELECT * FROM $muscle ORDER BY RAND() LIMIT 3";
                                    $result = $conn->query($sql);
                                    if ($result->num_rows > 0) 
                                    {
                                        // Output data of each user
                                        foreach($result as $row) {
                                    ?>
                                        <div class="col-lg-4 col-sm-6">
                                            <div class="ts-item set-bg" data-setbg="<?php echo $row['photo']; ?>">
                                                <div class="ts_text">
                                                    <h4><?php echo $row['name']; ?></h4>
                                                    <div class="tt_social">
                                                        <p><?php echo $row['submuscle']; ?></p>
                                                        <p>3 Sets x 12 Reps</p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    <?php
                                        }
                                    }      
                                }   
                        
                        } elseif ($currentDay == 'Tuesday') {
                            $muscleGroups = array("biceps", "back");
                            foreach ($muscleGroups as $muscle) {
                                $sql = "SELECT * FROM $muscle ORDER BY RAND() LIMIT 3";
                                $result = $conn->query($sql);
                                if ($result->num_rows > 0) 
                                {
                                    // Output data of each user
                                    foreach($result as $row) {
                                ?>
                                    <div class="col-lg-4 col-sm-6">
                                        <div class="ts-item set-bg" data-setbg="<?php echo $row['photo']; ?>">
                                            <div class="ts_text">
                                                <h4><?php echo $row['name']; ?></h4>
                                                <div class="tt_social">
                                                    <p><?php echo $row['submuscle']; ?></p>
                                                    <p>3 Sets x 12 Reps</p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                <?php
                                    }
                                }      
                            }  
                            
                        } elseif ($currentDay == 'Wednesday') {
                            $sql = "SELECT * FROM legs ORDER BY RAND() LIMIT 5";
                                    $result = $conn->query($sql);
                                    if ($result->num_rows > 0) 
                                    {
                                        // Output data of each user
                                        foreach($result as $row) {
                                    ?>
                                        <div class="col-lg-4 col-sm-6">
                                            <div class="ts-item set-bg" data-setbg="<?php echo $row['photo']; ?>">
                                                <div class="ts_text">
                                                    <h4><?php echo $row['name']; ?></h4>
                                                    <div class="tt_social">
                                                        <p><?php echo $row['submuscle']; ?></p>
                                                        <p>3 Sets x 12 Reps</p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    <?php
                                        }
                                    }
                            
                        } elseif ($currentDay == 'Thursday') {
                             $muscleGroups = array("chest", "shoulder", "triceps");
                                foreach ($muscleGroups as $muscle) {
                                    $sql = "SELECT * FROM $muscle ORDER BY RAND() LIMIT 3";
                                    $result = $conn->query($sql);
                                    if ($result->num_rows > 0) 
                                    {
                                        // Output data of each user
                                        foreach($result as $row) {
                                    ?>
                                        <div class="col-lg-4 col-sm-6">
                                            <div class="ts-item set-bg" data-setbg="<?php echo $row['photo']; ?>">
                                                <div class="ts_text">
                                                    <h4><?php echo $row['name']; ?></h4>
                                                    <div class="tt_social">
                                                        <p><?php echo $row['submuscle']; ?></p>
                                                        <p>3 Sets x 12 Reps</p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    <?php
                                        }
                                    }      
                                } 

                        } elseif ($currentDay == 'Friday') {
                            $muscleGroups = array("biceps", "back");
                            foreach ($muscleGroups as $muscle) {
                                $sql = "SELECT * FROM $muscle ORDER BY RAND() LIMIT 3";
                                $result = $conn->query($sql);
                                if ($result->num_rows > 0) 
                                {
                                    // Output data of each user
                                    foreach($result as $row) {
                                ?>
                                    <div class="col-lg-4 col-sm-6">
                                        <div class="ts-item set-bg" data-setbg="<?php echo $row['photo']; ?>">
                                            <div class="ts_text">
                                                <h4><?php echo $row['name']; ?></h4>
                                                <div class="tt_social">
                                                    <p><?php echo $row['submuscle']; ?></p>
                                                    <p>3 Sets x 12 Reps</p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                <?php
                                    }
                                }      
                            } 
                            
                        } else {
                            $sql = "SELECT * FROM legs ORDER BY RAND() LIMIT 5";
                            $result = $conn->query($sql);
                            if ($result->num_rows > 0) 
                            {
                                // Output data of each user
                                foreach($result as $row) {
                            ?>
                                <div class="col-lg-4 col-sm-6">
                                    <div class="ts-item set-bg" data-setbg="<?php echo $row['photo']; ?>">
                                        <div class="ts_text">
                                            <h4><?php echo $row['name']; ?></h4>
                                            <div class="tt_social">
                                                <p><?php echo $row['submuscle']; ?></p>
                                                <p>3 Sets x 12 Reps</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php
                                }
                            }     
                        }
                }
            }
        }
            if($level=="Advance")
            {
                if($days_passed>=1 && $days_passed<=365)
                {
                        if ($currentDay == 'Sunday') {
                            ?>
                                 <h3 style="text-align:center; color:white;">Rest Day</h3>   
                            <?php    
                        } elseif ($currentDay == 'Monday') {
                                $muscleGroups = array("chest", "shoulder", "triceps");
                                foreach ($muscleGroups as $muscle) {
                                    $sql = "SELECT * FROM $muscle ORDER BY RAND() LIMIT 2";
                                    $result = $conn->query($sql);
                                    if ($result->num_rows > 0) 
                                    {
                                        // Output data of each user
                                        foreach($result as $row) {
                                    ?>
                                        <div class="col-lg-4 col-sm-6">
                                            <div class="ts-item set-bg" data-setbg="<?php echo $row['photo']; ?>">
                                                <div class="ts_text">
                                                    <h4><?php echo $row['name']; ?></h4>
                                                    <div class="tt_social">
                                                        <p><?php echo $row['submuscle']; ?></p>
                                                        <p>5 Sets x 5 Reps</p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    <?php
                                        }
                                    }      
                                }   
                        
                        } elseif ($currentDay == 'Tuesday') {
                            $muscleGroups = array("biceps", "back");
                            foreach ($muscleGroups as $muscle) {
                                $sql = "SELECT * FROM $muscle ORDER BY RAND() LIMIT 3";
                                $result = $conn->query($sql);
                                if ($result->num_rows > 0) 
                                {
                                    // Output data of each user
                                    foreach($result as $row) {
                                ?>
                                    <div class="col-lg-4 col-sm-6">
                                        <div class="ts-item set-bg" data-setbg="<?php echo $row['photo']; ?>">
                                            <div class="ts_text">
                                                <h4><?php echo $row['name']; ?></h4>
                                                <div class="tt_social">
                                                    <p><?php echo $row['submuscle']; ?></p>
                                                    <p>5 Sets x 5 Reps</p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                <?php
                                    }
                                }      
                            }  
                            
                        } elseif ($currentDay == 'Wednesday') {
                            $sql = "SELECT * FROM legs ORDER BY RAND() LIMIT 5";
                                    $result = $conn->query($sql);
                                    if ($result->num_rows > 0) 
                                    {
                                        // Output data of each user
                                        foreach($result as $row) {
                                    ?>
                                        <div class="col-lg-4 col-sm-6">
                                            <div class="ts-item set-bg" data-setbg="<?php echo $row['photo']; ?>">
                                                <div class="ts_text">
                                                    <h4><?php echo $row['name']; ?></h4>
                                                    <div class="tt_social">
                                                        <p><?php echo $row['submuscle']; ?></p>
                                                        <p>5 Sets x 5 Reps</p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    <?php
                                        }
                                    }
                            
                        } elseif ($currentDay == 'Thursday') {
                             $muscleGroups = array("chest", "shoulder", "triceps");
                                foreach ($muscleGroups as $muscle) {
                                    $sql = "SELECT * FROM $muscle ORDER BY RAND() LIMIT 3";
                                    $result = $conn->query($sql);
                                    if ($result->num_rows > 0) 
                                    {
                                        // Output data of each user
                                        foreach($result as $row) {
                                    ?>
                                        <div class="col-lg-4 col-sm-6">
                                            <div class="ts-item set-bg" data-setbg="<?php echo $row['photo']; ?>">
                                                <div class="ts_text">
                                                    <h4><?php echo $row['name']; ?></h4>
                                                    <div class="tt_social">
                                                        <p><?php echo $row['submuscle']; ?></p>
                                                        <p>3 Sets x 12 Reps</p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    <?php
                                        }
                                    }      
                                } 

                        } elseif ($currentDay == 'Friday') {
                            $muscleGroups = array("biceps", "back");
                            foreach ($muscleGroups as $muscle) {
                                $sql = "SELECT * FROM $muscle ORDER BY RAND() LIMIT 3";
                                $result = $conn->query($sql);
                                if ($result->num_rows > 0) 
                                {
                                    // Output data of each user
                                    foreach($result as $row) {
                                ?>
                                    <div class="col-lg-4 col-sm-6">
                                        <div class="ts-item set-bg" data-setbg="<?php echo $row['photo']; ?>">
                                            <div class="ts_text">
                                                <h4><?php echo $row['name']; ?></h4>
                                                <div class="tt_social">
                                                    <p><?php echo $row['submuscle']; ?></p>
                                                    <p>3 Sets x 12 Reps</p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                <?php
                                    }
                                }      
                            } 
                            
                        } else {
                            $sql = "SELECT * FROM legs ORDER BY RAND() LIMIT 5";
                            $result = $conn->query($sql);
                            if ($result->num_rows > 0) 
                            {
                                // Output data of each user
                                foreach($result as $row) {
                            ?>
                                <div class="col-lg-4 col-sm-6">
                                    <div class="ts-item set-bg" data-setbg="<?php echo $row['photo']; ?>">
                                        <div class="ts_text">
                                            <h4><?php echo $row['name']; ?></h4>
                                            <div class="tt_social">
                                                <p><?php echo $row['submuscle']; ?></p>
                                                <p>3 Sets x 12 Reps</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php
                                }
                            }     
                         } 
                 }
                
            }
            ?>
                
                </div>
            </div>
        </div>
    </section>
    <!-- Team Section End -->

<?php
require "footer.php";
?>