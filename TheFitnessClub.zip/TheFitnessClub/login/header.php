<?php
// Start the session
session_start();
// Check if the user is not logged in and redirect to login page
if (!isset($_SESSION['username'])) {
    header("Location: ../login.php"); // Change "login.php" to the actual login page URL
    exit();
}
// Your SQL connection details
$servername = "localhost";
$username = "thefitne_david";
$password = "Waheguru97";
$dbname = "thefitne_main";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Retrieve username from session or any other identifier
$username = $_SESSION['username']; // Assuming you already have the username stored in the session

// Prepare and execute SQL query to fetch user info
$sql = "SELECT * FROM client_info WHERE username='$username'";
$result = $conn->query($sql);

if ($result->num_rows == 1) {
    // Fetch user information
    $row = $result->fetch_assoc();

    // Store user information into session variables
    $id = $row['client_no']; 
    $name = $row['name'];
    $email = $row['email'];
    $phone_no = $row['phone_no'];
    $weight = $row['weight'];
    $sex = $row['sex'];
    $membership_start = $row['membership_start_date'];
    $membership_end = $row['membership_end_date'];
    $level = $row['level'];
    $photo = $row['photo'];
    $height = $row['height'];
    $dob = $row['dob'];
    $activity_level = $row['activity_level'];
    $target = $row['target'];

    // Get current date
    $current_date = date("Y-m-d");
    $currentDay = date('l');

    // Calculate the number of days passed since joining
    $days_passed = floor((strtotime($current_date) - strtotime($membership_start)) / (60 * 60 * 24))+1;
    $age = floor((strtotime($current_date)-strtotime($dob)) / (60 * 60 * 24 * 365));

    function calculateTDEE($sex, $weight, $height, $age, $activity_level) {
        // Constants for Harris-Benedict equation
        $male_constant = 88.362;
        $female_constant = 447.593;
        $height_constant = 4.799;
        $age_constant = 5.677;
    
        // Calculate BMR based on gender
        if ($sex == 'male') {
            $bmr = ($male_constant + ($height_constant * $height) + ($weight * 13.397) - ($age_constant * $age));
        } elseif ($sex == 'female') {
            $bmr = ($female_constant + ($height_constant * $height) + ($weight * 9.247) - ($age_constant * $age));
        } else {
            return "Invalid gender. Please specify 'male' or 'female'.";
        }
    
        // Adjust BMR based on activity level
        switch ($activity_level) {
            case 'Sedentary':
                $tdee = $bmr * 1.2;
                break;
            case 'Lightly Active':
                $tdee = $bmr * 1.375;
                break;
            case 'Moderately Active':
                $tdee = $bmr * 1.55;
                break;
            case 'Very Active':
                $tdee = $bmr * 1.725;
                break;
            case 'Extra Active':
                $tdee = $bmr * 1.9;
                break;
            default:
                return "Invalid activity level. Please specify 'sedentary', 'lightly_active', 'moderately_active', 'very_active', or 'extra_active'.";
        }
    
        return $tdee;
    }
    
    
    $tdee = calculateTDEE($sex, $weight, $height, $age, $activity_level);
    $tdee = intval(round($tdee, 2));
    
    // now according to the target of the member we will add or remove calories.
    if($target=='Fat Loss'){
        $Required_calories = ($tdee - 250);
    }
    elseif($target=='Muscle Gain'){
        $Required_calories = ($tdee + 250);
    }
    else{
        // no change is calories.
    }
    if($activity_level=='Sedentary'||$activity_level=='Lightly Active'||$activity_level=='Moderately Active'){
        $protein = intval(($Required_calories * 0.20)/4);
        $carbohydrate = intval(($Required_calories * 0.50)/4);
        $fats = intval(($Required_calories * 0.30)/9);
    }
    elseif($activity_level=='Very Active'){
        $protein = intval(($Required_calories * 0.20)/4);
        $carbohydrate = intval(($Required_calories * 0.55)/4);
        $fats = intval(($Required_calories * 0.25)/9); 
    }
    elseif($activity_level=='Extra Active'){
        $protein = intval(($Required_calories * 0.20)/4);
        $carbohydrate = intval(($Required_calories * 0.60)/4);
        $fats = intval(($Required_calories * 0.20)/9); 
    }

    $bmi = intval($weight/(($height/100)*($height)/100));
    $proteinPerServing = ($protein/4);
    $carbohydratePerServing = ($carbohydrate/4);
    $fatsPerServing = ($fats/4);

}
?>
<!DOCTYPE html>
<html lang="zxx">

<head>
    <meta charset="UTF-8">
    <meta name="description" content="Gym Template">
    <meta name="keywords" content="Gym, unica, creative, html">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>thefitnessclub</title>

    <!-- Google Font -->
    <link href="https://fonts.googleapis.com/css?family=Muli:300,400,500,600,700,800,900&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Oswald:300,400,500,600,700&display=swap" rel="stylesheet">

    <!-- Css Styles -->
    <link rel="icon" type="image/png" href="./img/gym.png">
    <link rel="icon" type="image/png" href="path/to/your/logo.png">
    <link rel="stylesheet" href="css/bootstrap.min.css" type="text/css">
    <link rel="stylesheet" href="css/font-awesome.min.css" type="text/css">
    <link rel="stylesheet" href="css/flaticon.css" type="text/css">
    <link rel="stylesheet" href="css/owl.carousel.min.css" type="text/css">
    <link rel="stylesheet" href="css/barfiller.css" type="text/css">
    <link rel="stylesheet" href="css/magnific-popup.css" type="text/css">
    <link rel="stylesheet" href="css/slicknav.min.css" type="text/css">
    <link rel="stylesheet" href="css/style.css" type="text/css">
</head>

<body>
    <!-- Page Preloder -->
    <div id="preloder">
        <div class="loader"></div>
    </div>
    <!-- Offcanvas Menu Section Begin -->
    <div class="offcanvas-menu-overlay"></div>
    <div class="offcanvas-menu-wrapper">
        <div class="canvas-close">
            <i class="fa fa-close"></i>
        </div>
        <nav class="canvas-menu mobile-menu">
                     <ul>
                        <li class="active"><a href="./index.php">Home</a></li>
                        <li><a href="exercise_plan.php">Exercise Plan</a></li>
                        <li><a href="diet_plan.php">Diet Plan</a></li>
                        <li><a href="exercisechart.php">Exercise Chart</a></li>
                        <li><a href="./contact.php">Contact</a></li>
                        <li><a href="logout.php">logout</a></li>
                    </ul>
                    </nav>
        <div id="mobile-menu-wrap"></div>
    </div>
    <!-- Offcanvas Menu Section End -->

    <!-- Header Section Begin -->
    <header class="header-section">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-3">
                    <div class="logo">
                        <a href="./index.php">
                            <img src="img/logo.png" alt="">
                        </a>
                    </div>
                </div>
                <div class="col-lg-6">
                    <nav class="nav-menu">
                        <ul>
                            <li class="active"><a href="./index.php">Home</a></li>
                            <li><a href="exercise_plan.php">Exercise Plan</a></li>
                            <li><a href="diet_plan.php">Diet Plan</a></li>
                            <li><a href="exercisechart.php">Exercise Chart</a></li>
                            <li><a href="./contact.php">Contact</a></li>
                            <li><a href="logout.php">logout</a></li>
                        </ul>
                    </nav>
                </div>
                <div class="col-lg-3">
                    <div class="top-option">
                    </div>
                </div>
            </div>
            <div class="canvas-open">
                <i class="fa fa-bars"></i>
            </div>
        </div>
    </header>
    <!-- Header End -->
