<?php
require "header.php"; 

?>    

<!-- Breadcrumb Section Begin -->
<section class="breadcrumb-section set-bg" data-setbg="img/breadcrumb-bg.jpg">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 text-center">
                <div class="breadcrumb-text">
                    <h2>Welcome <?php echo $_SESSION['username']; ?></h2>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Breadcrumb Section End -->

<!-- Team Section Begin -->
<section class="team-section team-page spad">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="team-title">
                        <div class="section-title">
                            <h2>Your Profile</h2>
                        </div>
                        <a href="logout.php" class="primary-btn btn-normal appoinment-btn">logout</a>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-4 col-sm-6">
                    <div class="ts-item set-bg" data-setbg=".<?php echo $photo ?>">
                        <div class="ts_text">
                            <h4><?php echo $name ?></h4>
                            <span><p>Weight:- <?php echo $weight ?> kg</p></span>
                            <div class="tt_social"> 
                            <p>Level:-<?php echo $level?></p>
                            <p>Activity Level:-<?php echo $activity_level?></p>
                            <p>Target:- <?php echo $target ?></p>
                            <p>Membership End:- <?php echo $membership_end ?></p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-sm-6">
                    <div >
                        <div class="ts_text" style="text-align: center;">
                            <h2>Personal Details</h2>
                            <p>Email:-<?php echo $email?></p>
                            <p>Phone No:-<?php echo $phone_no?></p>
                            <p>Level:-<?php echo $level?></p>
                            <p>Sex:-<?php echo $sex?></p>
                            <p>Height:-<?php echo $height?></p>
                            <p>Activity Level:-<?php echo $activity_level?></p>
                            <p>Date Of Birth:-<?php echo $dob?></p>
                            <a href="edit_user.php" style=color:green>Edit</a>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-sm-6" style="text-align: center;">
                    <div >
                        <div class="ts_text">
                       <div class="mt-2 section-title">
                             <p class="mt-2 primary-btn btn-normal ">Body Mass Index - <?php echo $bmi?></p>
                        </div>
                        <div class="mt-2 section-title">
                             <p class="mt-2 primary-btn btn-normal ">Level - <?php echo $level?></p>
                        </div>
                        <div class="mt-2 section-title">
                             <p class="mt-2 primary-btn btn-normal ">Target - <?php echo $target?></p>
                        </div>
                        <div class="mt-2 section-title">
                             <p class="mt-2 primary-btn btn-normal ">Membership End - <?php echo $membership_end?></p>
                        </div> 
                        <div class="mt-2 section-title">
                              <p class="mt-2 primary-btn btn-normal ">Activity - <?php echo $activity_level?></p>
                        </div>  
                        </div>
                    </div>
                </div>
         </div>
    </div>
</section>
    <!-- Team Section End -->

<!-- User Info Section Begin -->
<section class="user-info-section">
    <div class="container">
        <div class="row">
            <!-- User Details Sidebar -->
            <div class="col-lg-4 offset-lg-1">
                    </div>
            <!-- End User Details Sidebar -->

            <!-- Empty Center Space -->
            <div class="col-lg-6">
                <!-- Leave this space empty -->
            </div>
            <!-- End Empty Center Space -->
        </div>
    </div>
</section>
<!-- User Info Section End -->

<?php
require "footer.php"; 
?>
