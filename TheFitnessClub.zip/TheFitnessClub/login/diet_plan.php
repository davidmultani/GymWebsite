<?php
require "header.php";
?>

<!-- Breadcrumb Section Begin -->
<section class="breadcrumb-section set-bg" data-setbg="img/breadcrumb-bg.jpg">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 text-center">
                <div class="breadcrumb-text">
                    <h2>Diet Plan</h2>
                    <h3 style="color:#f36100"><?php echo $currentDay ?></h3>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Breadcrumb Section End -->

<!-- Team Section Begin -->
<section class="team-section team-page spad">
        <div class="container">
            <div class="row">
            <div class="col-lg-4 col-sm-6" style="text-align: center;">
                    <div >
                        <div class="ts_text">
                       <div class="mt-2 section-title">
                              <h4 class=" primary-btn btn-normal stats">Calories Requirement - <?php echo $Required_calories?></h4>
                        </div>
                        <div class="mt-2 section-title">
                            <h4 class="primary-btn btn-normal stats">Protein Requirement - <?php echo $protein ?></h4>
                        </div>
                        <div class="mt-2 section-title">
                            <h4 class="primary-btn btn-normal stats">Carbohydrates Requirement - <?php echo $carbohydrate ?></h4>
                        </div>
                        <div class="mt-2 section-title">
                             <h4 class="primary-btn btn-normal stats">Fats Requirement - <?php echo $fats ?></h4>
                        </div> 
                        <div class="mt-2 section-title">
                             <h4 class="primary-btn btn-normal stats">Current Weight - <?php echo $weight?></h4>
                        </div>
                        <div class="mt-2 section-title">
                             <h4 class="mb-3 primary-btn btn-normal stats">Activity Level - <?php echo $activity_level?></h4>
                        </div>   
                        </div>
                    </div>
                </div>
            <?php 

            // SQL query to fetch users' information
            $sql = "SELECT * FROM maindiet";
            $result = $conn->query($sql);

            // Check if there are any users
            if ($result->num_rows > 0) {
                // Output data of each user
                foreach($result as $row) {
            ?>
              <div class="col-lg-4 col-sm-6">
                    <div class="ts-item set-bg" data-setbg="<?php echo $row['photo']; ?>">
                    <div class="ts_text">
                            <h4><?php echo $row['name']; ?></h4>
                            <div class="tt_social">
                                  <a href="dietPlanTime.php?dietPlan=<?php echo $row['name']?>" class="primary-btn btn-normal">view</a>
                            </div>
                        </div>
                    </div>
                </div>
            <?php
                }
            } else {
                echo "0 results";
            }
            // Close database connection
            $conn->close();
            ?>
                </div>
            </div>
        </div>
 </section>
    <!-- Team Section End -->

<?php
require "footer.php";
?>