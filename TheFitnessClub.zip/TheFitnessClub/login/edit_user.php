<?php
require "header.php"
?>  
<!-- Breadcrumb Section Begin -->
    <section class="breadcrumb-section set-bg" data-setbg="img/breadcrumb-bg.jpg">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 text-center">
                    <div class="breadcrumb-text">
                        <h2>Edit User</h2>
                        <div class="bt-option">
                            <span>Enter your Credentials</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Breadcrumb Section End -->

    <!-- Team Section Begin -->
    <section class="team-section team-page spad">
        <div class="container">
            <center>
                <div class="col-lg-6 col-sm-4 mx-auto">
                    <div class="leave-comment">
                        <?php
                        // Check for error message from registration process
                        if (isset($_GET['error'])) {
                            echo "<p style='color: red;' class='error-message'>Registration failed: " . $_GET['error'] . "</p>";
                        }
                        ?>
                        <form action="../edit_user_form.php?id=<?php echo $id ?>" method="post" enctype="multipart/form-data">
                            <input type="text" name="name" placeholder="Name" value="<?php echo $name ?>" required >
                            <input type="email" name="email" placeholder="Email" value="<?php echo $email ?>" disabled >
                            <input type="tel" name="phone_no" placeholder="Phone Number" value="<?php echo $phone_no ?>" disabled >
                            <div class="grid-row ">
                                <input type="number" name="weight" placeholder="Weight" value="<?php echo $weight ?>" required >
                                <input type="number" name="height" placeholder="Height" value="<?php echo $height ?>" max="220" required >
                                <input type="date" name="dob" placeholder="Date Of Birth" max="<?php echo date('Y-m-d'); ?>" value="<?php echo $row['dob']; ?>" required >
                                <select name="sex" required class="mb-3">
                                    <option value="" disabled>Select Sex</option>
                                    <option value="male" <?php if ($sex === "male") echo "selected"; ?>>Male</option>
                                    <option value="female" <?php if ($sex === "female") echo "selected"; ?>>Female</option>
                                </select>
                                <select name="level" required >
                                    <option value="" disabled>Select level</option>
                                    <option value="Beginner" <?php if ($level === "Beginner") echo "selected"; ?>>Beginner</option>
                                    <option value="Intermediate" <?php if ($level === "Intermediate") echo "selected"; ?>>Intermediate</option>
                                    <option value="Advance" <?php if ($level === "Advance") echo "selected"; ?>>Advance</option>
                                </select>
                                <select name="activity_level" required>
                                    <option value="" disabled selected>Select Activity Level</option>
                                    <option value="Sedentary" <?php if ($activity_level === "Sedentary") echo "selected"; ?> >Sedentary</option>
                                    <option value="Lightly Active" <?php if ($activity_level === "Lightly Active") echo "selected"; ?> >Lightly Active</option>
                                    <option value="Moderately Active" <?php if ($activity_level === "Moderately Active") echo "selected"; ?>>Moderately Active</option>
                                    <option value="Very Active" <?php if ($activity_level === "Very Active") echo "selected"; ?>>Very Active</option>
                                    <option value="Extra Active" <?php if ($activity_level === "Extra Active") echo "selected"; ?>>Extra Active</option>
                                </select>
                                <select name="target" required class="mt-3">
                                    <option value="" disabled selected>Select Target</option>
                                    <option value="Fat Loss" <?php if ($target === "Fat Loss") echo "selected"; ?>>Fat Loss</option>
                                    <option value="Muscle Gain" <?php if ($target === "Muscle Gain") echo "selected"; ?>>Muscle Gain</option>
                                    <option value="Get Fit" <?php if ($target === "Get Fit") echo "selected"; ?>>Get Fit</option>
                                </select>
                            </div>
                            <input type="text" name="username" placeholder="Username" value="<?php echo $username ?>" disabled class="mt-3"> 
                            <input type="password" name="password" placeholder="Password" required >
                            <input type="file" name="profile_picture" required value="<?php echo $photo ?>" />
                            <input type="submit" value="Update">
                      </form>
                    </div>
                </div>
            </center>
        </div>
    </section>
    <!-- Team Section End -->
    <?php
	require "footer.php"
	?>