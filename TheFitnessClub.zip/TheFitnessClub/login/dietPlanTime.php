<?php
require "header.php"; 
$dietPlan = strtolower($_GET['dietPlan']);
?>    

<!-- Breadcrumb Section Begin -->
<section class="breadcrumb-section set-bg" data-setbg="img/breadcrumb-bg.jpg">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 text-center">
                <div class="breadcrumb-text">
                    <h2><?php echo $dietPlan ?> Option</h2>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Breadcrumb Section End -->

<!-- Team Section Begin -->
<section class="team-section team-page spad">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="team-title">
                    <div class="section-title">
                        <h2><?php echo $dietPlan ?></h2>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <?php 
            // Include database connection
            require "connect.php";

            // SQL query to fetch users' information
            $sql = "SELECT * FROM $dietPlan ORDER BY RAND() LIMIT 1";
            $result = $conn->query($sql);

            // Check if there are any users
            if ($result->num_rows > 0) {
                // Output data of each user
                foreach($result as $row) {
            ?>
                <div class="col-lg-4 col-sm-6">
                    <div class="ts-item set-bg" data-setbg="<?php echo $row['photo']; ?>">
                        <div class="ts_text">
                            <?php ?>
                            <h4><?php echo $row['name']; ?> - <?php echo round($proteinPerServing/$row['protein']);?> Servings</h4>
                            <div class="tt_social">
                            <p><?php echo $row['description']; ?></p>
                            <p>Serving Size:- <?php echo $row['servingsize']; ?></p>
                            <p>Protein:- <?php echo $row['protein']; ?></p>
                            <p>Carbohydrates:- <?php echo $row['carbohydrates']; ?></p>
                            <p>Fats:- <?php echo $row['fats']; ?></p>
                            <p>Type:- <?php echo $row['type']; ?></p>
                            </div>
                        </div>
                    </div>
                </div>
            <?php
                }
            } else {
                echo "0 results";
            }
            // Close database connection
            $conn->close();
            ?>
        </div>
    </div>
</section>
<!-- Team Section End -->

<!-- User Info Section Begin -->
<section class="user-info-section">
    <div class="container">
        <div class="row">
            <!-- User Details Sidebar -->
            <div class="col-lg-4 offset-lg-1">
                <!-- Add any additional user details sidebar content here -->
            </div>
            <!-- End User Details Sidebar -->

            <!-- Empty Center Space -->
            <div class="col-lg-6">
                <!-- Leave this space empty -->
            </div>
            <!-- End Empty Center Space -->
        </div>
    </div>
</section>
<!-- User Info Section End -->

<?php
require "footer.php"; 
?>
