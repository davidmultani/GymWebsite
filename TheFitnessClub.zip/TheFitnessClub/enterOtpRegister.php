<?php
require "header.php";
?>    
<!-- Breadcrumb Section Begin -->
    <section class="breadcrumb-section set-bg" data-setbg="img/breadcrumb-bg.jpg">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 text-center">
                    <div class="breadcrumb-text">
                        <h2>Email Verification</h2>
                        <div class="bt-option">
                            <span>Enter your Credentials</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Breadcrumb Section End -->

    <!-- Login Section Begin -->
    <section class="team-section team-page spad">
        <div class="container">
            <center>
                <div class="col-lg-6 col-sm-4">
                    <div class="leave-comment">

                        <?php

                        // Check if an error parameter is present in the URL
                        if (isset($_GET['update'])) {
                            if ($_GET['update'] === 'invalidotp') {
                                echo "<p style='color: red; font-size:15px;'>Invalid Otp. Pleaee Try Again. </p>";
                            }
                            else {
                                echo "<p style='color: red; font-size:15px;'>An unknown error occurred</p>";
                            }
                        }
                        ?>
                        
                        <form action="verifyOtpRegister.php" method="post" onsubmit="return validateForm()">
                            <input type="email" placeholder="Enter the Registered Email" name="email" value="<?php echo $_SESSION['email'];?>" disabled>
                            <input type="number" placeholder="Enter Otp" name="otp" required> 
                            <button type="submit" class="primary-btn btn-normal appoinment-btn">Submit</button>
                        </form>
                    </div>
                    <p id="error-message" class="error-message"></p>
                    <div class="p-2">
                    </div>
                </div>
            </center>
        </div>
    </section>
    <!-- Team Section End -->
    <?php
	require "footer.php"
	?>