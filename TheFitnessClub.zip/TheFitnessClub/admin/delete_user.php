<?php
// Your SQL connection details
require "connect.php";
// Retrieve user ID from GET request
$id = $_GET['id']; 

// Sanitize user ID before using in SQL query (to prevent SQL injection)
$id = mysqli_real_escape_string($conn, $id);

// SQL query to delete user
$sql = "DELETE FROM client_info WHERE client_no='$id'";

// Execute query
$result = $conn->query($sql);

if ($result === TRUE) {
    // Deletion successful, redirect to wherever you want
    header("Location: index.php?delete=success");
    exit(); // Terminate script to prevent further execution
} else {
    // Deletion failed, redirect back with error message
    header("Location: index.php?error=" . urlencode("Deletion failed: " . $conn->error));
    exit(); // Terminate script to prevent further execution
}

$conn->close();
?>