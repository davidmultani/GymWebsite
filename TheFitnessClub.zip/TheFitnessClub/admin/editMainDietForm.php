<?php
require "connect.php";

// Retrieve registration data from POST request
$name = $_POST['category'];
$mid = $_GET['mid'];

// Check if file is uploaded successfully
if ($_FILES['category_picture']['error'] === UPLOAD_ERR_OK) {
    // Retrieve information about the uploaded file
    $fileTmpPath = $_FILES['category_picture']['tmp_name'];
    $fileName = $_FILES['category_picture']['name'];
    $fileSize = $_FILES['category_picture']['size'];
    $fileType = $_FILES['category_picture']['type'];
    
    // Specify the folder where you want to store the uploaded files
    $uploadDirectory = '../img/mainDietCategory/';

    // Move the uploaded file to the desired destination
    $destPath = $uploadDirectory . $fileName;
    if (!move_uploaded_file($fileTmpPath, $destPath)) {
        // File move failed, handle the error accordingly
        header("Location: addMainDiet.php?error=" . urlencode("Failed to move uploaded file"));
        exit(); // Terminate script to prevent further execution
    }
} else {
    // File upload failed, handle the error accordingly
    header("Location: addMainDiet.php?error=" . urlencode("File upload failed: " . $_FILES['category_picture']['error']));
    exit(); // Terminate script to prevent further execution
}
 
// Sanitize inputs before using in SQL query (to prevent SQL injection)
$name = mysqli_real_escape_string($conn, $name);
$destPath = mysqli_real_escape_string($conn, $destPath);

// SQL query to update user info
$sql = "UPDATE maindiet SET name='$name', photo='$destPath' WHERE mid=$mid";

// Execute query
$result = $conn->query($sql);

if ($result === TRUE) {
    // Update successful, redirect to wherever you want
    header("Location: dietChart.php?update=success");
    exit(); // Terminate script to prevent further execution
} else {
    // Update failed, redirect back with error message
    header("Location: addMainDiet.php?error=" . urlencode("Update failed: " . $conn->error));
    exit(); // Terminate script to prevent further execution
}

$conn->close();
?>
