<?php 
require "header.php";
?>
<!-- Breadcrumb Section Begin -->
<section class="breadcrumb-section set-bg" data-setbg="img/breadcrumb-bg.jpg">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 text-center">
                <div class="breadcrumb-text">
                    <h2>Contact Form</h2>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Breadcrumb Section End -->
<!-- Testimonial Section Begin -->
<section class="testimonial-section spad">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="section-title">
                        <span>People Contacted</span>
                        <h2>Their Messages</h2>
                    </div>
                </div>
            </div>
            <div class="ts_slider owl-carousel">
                <?php 
                // SQL query to fetch users' information
                $sql = "SELECT * FROM contact_form";
                $result = $conn->query($sql);

                // Check if there are any users
                if ($result->num_rows > 0) {
                    // Output data of each user
                    foreach($result as $row) {
                ?>
                <div class="ts_item">
                    <div class="row">
                        <div class="col-lg-12 text-center">
                            <div class="ti_pic">
                                <h2><?php echo $row['comment'];?></h2>
                            </div>
                            <div class="ti_text">
                                <h5><?php echo $row['name'];?></h5>
                                <p><?php echo $row['email'];?></p>
                                <p><?php echo $row['phone_no'];?></p>
                                <a href="deleteComment.php?f_id=<?php echo $row['f_id'];?>" class="primary-btn btn-normal appoinment-btn">Delete</a>
                            </div>
                        </div>
                    </div>
                </div>
                <?php
                    }
                } else {
                    echo "0 results";
                }
                // Close database connection
                $conn->close();
                ?>
            </div>
        </div>
    </section>
    <!-- Testimonial Section End -->
<?php
require "footer.php"
?>
