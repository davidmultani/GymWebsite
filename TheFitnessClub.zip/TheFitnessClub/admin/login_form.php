<?php
require "connect.php";
// Retrieve username and password from POST request
$username = $_POST['username'];
$password = $_POST['password'];

// Prepare SQL statement with parameterized query
$sql = "SELECT * FROM admin_info WHERE username=?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $username);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    // User found, verify password
    $row = $result->fetch_assoc();
    if (password_verify($password, $row['password'])) {
        //create a session and store the user information
        session_start();
        $_SESSION['username']=$username;
        // Password is correct, redirect to success page or perform further actions
        header("Location: ./index.php");
        exit(); // Terminate script to prevent further execution
    } 
    else {
        // Incorrect password, redirect back to login page with error message
        header("Location: ../admin_login.php?error=incorrect");
        exit(); // Terminate script to prevent further execution
    }
} 
else 
{
    // User not found, redirect back to login page with error message
    header("Location: ../admin_login.php?error=incorrect");
    exit(); // Terminate script to prevent further execution
}

$stmt->close();
$conn->close();
?>
