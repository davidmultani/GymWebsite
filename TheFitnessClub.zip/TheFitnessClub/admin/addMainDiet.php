<?php
require "header.php"
?>    
<!-- Breadcrumb Section Begin -->
    <section class="breadcrumb-section set-bg" data-setbg="img/breadcrumb-bg.jpg">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 text-center">
                    <div class="breadcrumb-text">
                        <h2>Add Main Category</h2>
                        <div class="bt-option">
                            <span>Enter Information</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Breadcrumb Section End -->

    <!-- Login Section Begin -->
    <section class="team-section team-page spad">
        <div class="container">
            <center>
                <div class="col-lg-6 col-sm-4">
                    <div class="leave-comment">                        
                        <form action="add_main_diet_form.php" method="post" enctype="multipart/form-data">
                            <input type="text" placeholder="Enter Main Category" name="category" >
                            <input type="file" name="category_picture" required />      
                            <button type="submit" class="primary-btn btn-normal appoinment-btn">Add</button>
                        </form>
                    </div>
                </div>
            </center>
        </div>
    </section>
    <!-- shake on login fail script -->
    <script>
        
    </script>
    <!-- Team Section End -->
    <?php
	require "footer.php"
	?>