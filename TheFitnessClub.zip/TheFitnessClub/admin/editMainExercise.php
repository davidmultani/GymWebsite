<?php
require "header.php"
?>  
<?php
 $mid=$_GET['mid'];
// Prepare and execute SQL query to fetch user info
$sql = "SELECT * FROM mainexercise WHERE mid='$mid'";
$result = $conn->query($sql);

if ($result->num_rows == 1) {
    // Fetch user information
    $row = $result->fetch_assoc();
}
?>   
<!-- Breadcrumb Section Begin -->
    <section class="breadcrumb-section set-bg" data-setbg="img/breadcrumb-bg.jpg">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 text-center">
                    <div class="breadcrumb-text">
                        <h2>Edit Main Category</h2>
                        <div class="bt-option">
                            <span>Enter Information</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Breadcrumb Section End -->

    <!-- Login Section Begin -->
    <section class="team-section team-page spad">
        <div class="container">
            <center>
                <div class="col-lg-6 col-sm-4">
                    <div class="leave-comment">                        
                        <form action="editMainExerciseForm.php?mid=<?php echo $mid?>" method="post" enctype="multipart/form-data">
                            <input type="text" placeholder="Enter Main Category" name="category" value="<?php echo $row['name'];?>">
                            <input type="file" name="category_picture" required />      
                            <button type="submit" class="primary-btn btn-normal appoinment-btn">Update</button>
                        </form>
                    </div>
                </div>
            </center>
        </div>
    </section>
    <!-- shake on login fail script -->
    <script>
        
    </script>
    <!-- Team Section End -->
    <?php
	require "footer.php"
	?>