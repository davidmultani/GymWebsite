<?php
// Your SQL connection details
require "connect.php";
// Retrieve user ID from GET request
$id = $_GET['id']; 
$muscle=$_GET['muscle'];

// Sanitize user ID before using in SQL query (to prevent SQL injection)
$id = mysqli_real_escape_string($conn, $id);

// SQL query to delete user
$sql = "DELETE FROM $muscle WHERE m_id='$id'";

// Execute query
$result = $conn->query($sql);

if ($result === TRUE) {
    // Deletion successful, redirect to wherever you want
    header("Location: exercise.php?muscle=".$muscle);
    exit(); // Terminate script to prevent further execution
} else {
    // Deletion failed, redirect back with error message
    header("Location: exercise.php?muscle=".$muscle."&error=" . urlencode("Deletion failed: " . $conn->error));
    exit(); // Terminate script to prevent further execution
}

$conn->close();
?>