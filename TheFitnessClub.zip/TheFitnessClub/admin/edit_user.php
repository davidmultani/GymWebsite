<?php
require "header.php"
?>  
 <?php
 $id=$_GET['id'];
// Prepare and execute SQL query to fetch user info
$sql = "SELECT * FROM client_info WHERE client_no='$id'";
$result = $conn->query($sql);

if ($result->num_rows == 1) {
    // Fetch user information
    $row = $result->fetch_assoc();
}
?> 
<!-- Breadcrumb Section Begin -->
    <section class="breadcrumb-section set-bg" data-setbg="img/breadcrumb-bg.jpg">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 text-center">
                    <div class="breadcrumb-text">
                        <h2>Edit User</h2>
                        <div class="bt-option">
                            <span>Enter your Credentials</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Breadcrumb Section End -->

    <!-- Team Section Begin -->
    <section class="team-section team-page spad">
        <div class="container">
            <center>
                <div class="col-lg-6 col-sm-4 mx-auto">
                    <div class="leave-comment">
                        <?php
                        // Check for error message from registration process
                        if (isset($_GET['error'])) {
                            echo "<p style='color: red;' class='error-message'>Registration failed: " . $_GET['error'] . "</p>";
                        }
                        ?>
                        <form action="edit_user_form.php?id=<?php echo $row['client_no']?>" method="post" enctype="multipart/form-data">
                        <input type="text" name="name" placeholder="Name" value="<?php echo $row['name'] ?>" required>
                            <input type="email" name="email" placeholder="Email" value="<?php echo $row['email'] ?>">
                            <input type="tel" name="phone_no" placeholder="Phone Number" value="<?php echo $row['phone_no'] ?>">
                            <div class="grid-row ">
                                <input type="number" name="weight" placeholder="Weight" value="<?php echo $row['weight'] ?>" required class="primary-btn btn-normal appoinment-btn">
                                <input type="number" name="height" placeholder="Height" value="<?php echo $row['height'] ?>" max="220" required class="primary-btn btn-normal appoinment-btn">
                                <input type="date" name="dob" placeholder="Date Of Birth" max="<?php echo date('Y-m-d'); ?>" value="<?php echo $row['dob']; ?>" required class="primary-btn btn-normal appoinment-btn">
                                <select name="sex" required class="mb-4 primary-btn btn-normal appoinment-btn">
                                    <option value="" disabled>Select Sex</option>
                                    <option value="male" <?php if ($row['sex'] === "male") echo "selected"; ?>>Male</option>
                                    <option value="female" <?php if ($row['sex'] === "female") echo "selected"; ?>>Female</option>
                                </select>
                                <select name="level" required class="mb-4 primary-btn btn-normal appoinment-btn">
                                    <option value="" disabled>Select level</option>
                                    <option value="Beginner" <?php if ($row['level'] === "Beginner") echo "selected"; ?>>Beginner</option>
                                    <option value="Intermediate" <?php if ($row['level'] === "Intermediate") echo "selected"; ?>>Intermediate</option>
                                    <option value="Advance" <?php if ($row['level'] === "Advance") echo "selected"; ?>>Advance</option>
                                </select>
                                <select name="activity_level" required class="mb-4 primary-btn btn-normal appoinment-btn primary-btn btn-normal appoinment-btn">
                                    <option value="" disabled selected>Select Activity Level</option>
                                    <option value="Sedentary" <?php if ($row['activity_level'] === "Sedentary") echo "selected"; ?> >Sedentary</option>
                                    <option value="Lightly Active" <?php if ($row['activity_level'] === "Lightly Active") echo "selected"; ?> >Lightly Active</option>
                                    <option value="Moderately Active" <?php if ($row['activity_level'] === "Moderately Active") echo "selected"; ?>>Moderately Active</option>
                                    <option value="Very Active" <?php if ($row['activity_level'] === "Very Active") echo "selected"; ?>>Very Active</option>
                                    <option value="Extra Active" <?php if ($row['activity_level'] === "Extra Active") echo "selected"; ?>>Extra Active</option>
                                </select>
                                <select name="target" required class="mb-3 primary-btn btn-normal appoinment-btn">
                                    <option value="" disabled selected>Select Target</option>
                                    <option value="Fat Loss" <?php if ($row['target'] === "Fat Loss") echo "selected"; ?>>Fat Loss</option>
                                    <option value="Muscle Gain" <?php if ($row['target'] === "Muscle Gain") echo "selected"; ?>>Muscle Gain</option>
                                    <option value="Get Fit" <?php if ($row['target'] === "Get Fit") echo "selected"; ?>>Get Fit</option>
                                </select>
                                <input type="date" name="membership_end_date" placeholder="Membership End Date" value="<?php echo $row['membership_end_date']; ?>"
                                 required class="primary-btn btn-normal appoinment-btn">
                            </div>
                            <input type="text" name="username" placeholder="Username" value="<?php echo $row['username'] ?>">
                            <input type="submit" value="Update">
                    </form>
                    </div>
                </div>
            </center>
        </div>
    </section>
    <!-- Team Section End -->
    <?php
	require "footer.php"
	?>