<?php
require "header.php";
$dietPlan=strtolower($_GET['dietPlan']);
$fid=$_GET['fid'];
?>
<?php
// Prepare and execute SQL query to fetch user info
$sql = "SELECT * FROM $dietPlan WHERE fid='$fid'";
$result = $conn->query($sql);

if ($result->num_rows == 1) {
    // Fetch user information
    $row = $result->fetch_assoc();
}
?>      
<!-- Breadcrumb Section Begin -->
    <section class="breadcrumb-section set-bg" data-setbg="img/breadcrumb-bg.jpg">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 text-center">
                    <div class="breadcrumb-text">
                        <h2>Edit Diet Plan</h2>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Breadcrumb Section End -->

    <!-- Team Section Begin -->
    <section class="team-section team-page spad">
        <div class="container">
            <center>
                <div class="col-lg-6 col-sm-4 mx-auto">
                    <div class="leave-comment">
                        <?php
                        // Check for error message from registration process
                        if (isset($_GET['error'])) {
                            echo "<p style='color: red;' class='error-message'>Registration failed: " . $_GET['error'] . "</p>";
                        }
                        ?>
                        <form action="./editDietPlanForm.php?fid=<?php echo $row['fid']; ?>" method="post" enctype="multipart/form-data">
                            <div class="grid-row">
                            <select name="dietPlan" required class="mb-4">
                                    <option value="" disabled selected>Select Diet Plan</option>
                                    <option value="Breakfast" <?php if($dietPlan == "breakfast") { echo "selected";}?>>Breakfast</option>
                                    <option value="Snack" <?php if($dietPlan == "snack") { echo "selected";}?>>Snack</option>
                                    <option value="Lunch" <?php if($dietPlan == "lunch") { echo "selected";}?>>Lunch</option>
                                    <option value="Dinner" <?php if($dietPlan == "dinner") { echo "selected";}?>>Dinner</option>
                                </select>
                            </div>
                            <input type="text" name="name" placeholder="Dish Name" required value="<?php echo $row['name'];?>">
                            <input type="text" name="description" placeholder="Description" required value="<?php echo $row['description'];?>">
                            <input type="text" name="servingsize" placeholder="Serving Size" required value="<?php echo $row['servingsize'];?>">
                            <input type="text" name="protein" placeholder="Protein" required value="<?php echo $row['protein'];?>">
                            <input type="text" name="carbohydrates" placeholder="Carbohydrates" required value="<?php echo $row['carbohydrates'];?>">
                            <input type="text" name="fats" placeholder="Fats" required value="<?php echo $row['fats'];?>">
                            <select name="type" required class="mb-4">
                                    <option value="" disabled selected>Select Diet Type</option>
                                    <option value="Veg" <?php if($row['type'] == "Veg") { echo "selected";}?>>Veg</option>
                                    <option value="Non-Veg" <?php if($row['type'] == "Non-Veg") { echo "selected";}?>>Non-Veg</option>
                                </select>
                            <input type="file" name="dish_picture" required/>
                            <input type="submit" value="Update">
                        </form>
                    </div>
                </div>
            </center>
        </div>
    </section>
    <!-- Team Section End -->
    <?php
	require "footer.php"
	?>