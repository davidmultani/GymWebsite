<?php
// Your SQL connection details
require "connect.php";
// Retrieve user ID from GET request
$fid = $_GET['fid']; 
$dietPlan=strtolower($_GET['dietPlan']);

// Sanitize user ID before using in SQL query (to prevent SQL injection)
$fid = mysqli_real_escape_string($conn, $fid);

// SQL query to delete user
$sql = "DELETE FROM $dietPlan WHERE fid='$fid'";

// Execute query
$result = $conn->query($sql);

if ($result === TRUE) {
    // Deletion successful, redirect to wherever you want
    header("Location: dietPlan.php?dietPlan=$dietPlan");
    exit(); // Terminate script to prevent further execution
} else {
    // Deletion failed, redirect back with error message
    header("Location: dietChart.php?error=" . urlencode("Deletion failed: " . $conn->error));
    exit(); // Terminate script to prevent further execution
}

$conn->close();
?>