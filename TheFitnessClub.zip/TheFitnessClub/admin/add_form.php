<?php
require "connect.php";

// Retrieve registration data from POST request
$muscle = $_POST['muscle'];
$submuscle = $_POST['submuscle'];
$exercise_name=$_POST['exercise_name'];
$muscle_picture=$_POST['muscle_picture'];


// Check if file is uploaded successfully
if ($_FILES['muscle_picture']['error'] === UPLOAD_ERR_OK) {
    // Retrieve information about the uploaded file
    $fileTmpPath = $_FILES['muscle_picture']['tmp_name'];
    $fileName = $_FILES['muscle_picture']['name'];
    $fileSize = $_FILES['muscle_picture']['size'];
    $fileType = $_FILES['muscle_picture']['type'];
    
    // Specify the folder where you want to store the uploaded files
    $uploadDirectory = '../login/img/muscles/';

    // Move the uploaded file to the desired destination
    $destPath = $uploadDirectory . $fileName;
    if (!move_uploaded_file($fileTmpPath, $destPath)) {
        // File move failed, handle the error accordingly
        header("Location: add.php?error=" . urlencode("Failed to move uploaded file"));
        exit(); // Terminate script to prevent further execution
    }
} else {
    // File upload failed, handle the error accordingly
    header("Location: add.php?muscle=".$muscle."error=" . urlencode("File upload failed: " . $_FILES['muscle_picture']['error']));
    exit(); // Terminate script to prevent further execution
}

// Sanitize inputs before using in SQL query (to prevent SQL injection)
$muscle = mysqli_real_escape_string($conn, $muscle);
$submuscle = mysqli_real_escape_string($conn, $submuscle);
$exercise_name = mysqli_real_escape_string($conn, $exercise_name);
$destPath = mysqli_real_escape_string($conn, $destPath);

// SQL query to insert new user
$sql = "INSERT INTO ".$muscle." (submuscle,name, photo)  VALUES ('$submuscle','$exercise_name', '$destPath')";

// Execute query
$result = $conn->query($sql);

if ($result === TRUE) {
    header("Location: exercise.php?muscle=".$muscle."&ExerciseAddedSuccessful");
    exit();
} else {
    header("Location: add.php?muscle=".$muscle."error=" . urlencode("failed: " . $conn->error));
    exit(); // Terminate script to prevent further execution
}

$conn->close();
?>
