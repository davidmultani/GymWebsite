<?php
require "header.php";
$dietPlan=strtolower($_GET['dietPlan']);
?>    
<!-- Breadcrumb Section Begin -->
    <section class="breadcrumb-section set-bg" data-setbg="img/breadcrumb-bg.jpg">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 text-center">
                    <div class="breadcrumb-text">
                        <h2>Add Diet Plan</h2>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Breadcrumb Section End -->

    <!-- Team Section Begin -->
    <section class="team-section team-page spad">
        <div class="container">
            <center>
                <div class="col-lg-6 col-sm-4 mx-auto">
                    <div class="leave-comment">
                        <?php
                        // Check for error message from registration process
                        if (isset($_GET['error'])) {
                            echo "<p style='color: red;' class='error-message'>Registration failed: " . $_GET['error'] . "</p>";
                        }
                        ?>
                        <form action="./addDietForm.php" method="post" enctype="multipart/form-data">
                            <div class="grid-row">
                            <select name="dietPlan" required class="mb-4">
                                    <option value="" disabled selected>Select Diet Plan</option>
                                    <option value="Breakfast" <?php if($dietPlan == "breakfast") { echo "selected";}?>>Breakfast</option>
                                    <option value="Snack" <?php if($dietPlan == "snack") { echo "selected";}?>>Snack</option>
                                    <option value="Lunch" <?php if($dietPlan == "lunch") { echo "selected";}?>>Lunch</option>
                                    <option value="Dinner" <?php if($dietPlan == "dinner") { echo "selected";}?>>Dinner</option>
                                </select>
                            </div>
                            <input type="text" name="name" placeholder="Dish Name" required>
                            <input type="text" name="description" placeholder="Description" required>
                            <input type="text" name="servingsize" placeholder="Serving Size" required>
                            <input type="text" name="protein" placeholder="Protein" required>
                            <input type="text" name="carbohydrates" placeholder="Carbohydrates" required>
                            <input type="text" name="fats" placeholder="Fats" required>
                            <select name="type" required class="mb-4">
                                    <option value="" disabled selected>Select Diet Type</option>
                                    <option value="Veg">Veg</option>
                                    <option value="Non-Veg">Non-Veg</option>
                                </select>
                            <input type="file" name="dish_picture" required/>
                            <input type="submit" value="Add">
                        </form>
                    </div>
                </div>
            </center>
        </div>
    </section>
    <!-- Team Section End -->
    <?php
	require "footer.php"
	?>