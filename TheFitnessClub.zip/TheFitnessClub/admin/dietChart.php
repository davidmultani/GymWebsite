<?php
require "header.php"; 
?>    

<!-- Breadcrumb Section Begin -->
<section class="breadcrumb-section set-bg" data-setbg="img/breadcrumb-bg.jpg">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 text-center">
                <div class="breadcrumb-text">
                    <h2>Available Diet Plans</h2>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Breadcrumb Section End -->

<!-- Team Section Begin -->
<section class="team-section team-page spad">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="team-title">
                    <div class="section-title">
                        <h2>Types of Diet Plans</h2>
                    </div>
                    <a href="addMainDiet.php" class="primary-btn btn-normal appoinment-btn">Add</a>
                </div>
            </div>
        </div>
        <div class="row">
            <?php 
            // Include database connection
            require "connect.php";

            // SQL query to fetch users' information
            $sql = "SELECT * FROM maindiet";
            $result = $conn->query($sql);

            // Check if there are any users
            if ($result->num_rows > 0) {
                // Output data of each user
                foreach($result as $row) {
            ?>
              <div class="col-lg-4 col-sm-6">
                    <div class="ts-item set-bg" data-setbg="<?php echo $row['photo']; ?>">
                    <div class="ts_text">
                            <h4><?php echo $row['name']; ?></h4>
                            <div class="tt_social">
                                <a href="deleteDietChart.php?mid=<?php echo $row['mid']?>" class="primary-btn btn-normal appoinment-btn">Delete</a>
                                <a href="editDietChart.php?mid=<?php echo $row['mid']?>" class="primary-btn btn-normal appoinment-btn">Edit</a>
                                <a href="dietPlan.php?dietPlan=<?php echo $row['name']?>" class="primary-btn btn-normal appoinment-btn">view</a>
                            </div>
                        </div>
                    </div>
                </div>
            <?php
                }
            } else {
                echo "0 results";
            }
            // Close database connection
            $conn->close();
            ?>
        </div>
    </div>
</section>
<!-- Team Section End -->

<!-- User Info Section Begin -->
<section class="user-info-section">
    <div class="container">
        <div class="row">
            <!-- User Details Sidebar -->
            <div class="col-lg-4 offset-lg-1">
                <!-- Add any additional user details sidebar content here -->
            </div>
            <!-- End User Details Sidebar -->

            <!-- Empty Center Space -->
            <div class="col-lg-6">
                <!-- Leave this space empty -->
            </div>
            <!-- End Empty Center Space -->
        </div>
    </div>
</section>
<!-- User Info Section End -->

<?php
require "footer.php"; 
?>
