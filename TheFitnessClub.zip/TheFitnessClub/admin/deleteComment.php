<?php
// Your SQL connection details
require "connect.php";
// Retrieve user ID from GET request
$f_id = $_GET['f_id']; 

// Sanitize user ID before using in SQL query (to prevent SQL injection)
$f_id = mysqli_real_escape_string($conn, $f_id);

// SQL query to delete user
$sql = "DELETE FROM contact_form WHERE f_id='$f_id'";

// Execute query
$result = $conn->query($sql);

if ($result === TRUE) {
    // Deletion successful, redirect to wherever you want
    header("Location: contact.php");
    exit(); // Terminate script to prevent further execution
} else {
    // Deletion failed, redirect back with error message
    header("Location: contact.php?error=" . urlencode("Deletion failed: " . $conn->error));
    exit(); // Terminate script to prevent further execution
}

$conn->close();
?>