<?php
// Start the session
session_start();
// Check if the user is not logged in and redirect to login page
if (!isset($_SESSION['username'])) {
    header("Location: ../admin_login.php"); // Change "login.php" to the actual login page URL
    exit();
}
// Your SQL connection details
$servername = "localhost";
$username = "thefitne_david";
$password = "Waheguru97";
$dbname = "thefitne_main";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Retrieve username from session or any other identifier
$username = $_SESSION['username']; // Assuming you already have the username stored in the session

// Prepare and execute SQL query to fetch user info
$sql = "SELECT * FROM admin_info WHERE username='$username'";
$result = $conn->query($sql);

if ($result->num_rows == 1) {
    // Fetch user information
    $row = $result->fetch_assoc();

    // Store user information into session variables
    $_SESSION['admin_id'] = $row['admin_id'];
    $_SESSION['name'] = $row['name'];
    $_SESSION['username'] = $row['username'];
    $_SESSION['email'] = $row['email'];
    $_SESSION['phone_no'] = $row['phone_no'];
    $_SESSION['photo'] = $row['photo'];
    // Add other fields as needed
}
?>
<!DOCTYPE html>
<html lang="zxx">

<head>
    <meta charset="UTF-8">
    <meta name="description" content="Gym Template">
    <meta name="keywords" content="Gym, unica, creative, html">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>thefitnessclub</title>

    <!-- Google Font -->
    <link href="https://fonts.googleapis.com/css?family=Muli:300,400,500,600,700,800,900&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Oswald:300,400,500,600,700&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">

    <!-- Css Styles -->
    <link rel="stylesheet" href="css/bootstrap.min.css" type="text/css">
    <link rel="stylesheet" href="css/font-awesome.min.css" type="text/css">
    <link rel="stylesheet" href="css/flaticon.css" type="text/css">
    <link rel="stylesheet" href="css/owl.carousel.min.css" type="text/css">
    <link rel="stylesheet" href="css/barfiller.css" type="text/css">
    <link rel="stylesheet" href="css/magnific-popup.css" type="text/css">
    <link rel="stylesheet" href="css/slicknav.min.css" type="text/css">
    <link rel="stylesheet" href="css/style.css" type="text/css">
</head>

<body>
    <!-- Page Preloder -->
    <div id="preloder">
        <div class="loader"></div>
    </div>
    <!-- Offcanvas Menu Section Begin -->
    <div class="offcanvas-menu-overlay"></div>
    <div class="offcanvas-menu-wrapper">
        <div class="canvas-close">
            <i class="fa fa-close"></i>
        </div>
        <div class="canvas-search search-switch">
            <i class="fa fa-search"></i>
        </div>
        <nav class="canvas-menu mobile-menu">
                     <ul>
                        <li class="active"><a href="./index.php">Home</a></li>
                        <li><a href="dietChart.php">Diet Plan</a></li>
                        <li><a href="exercisechart.php">Exercise Chart</a></li>
                        <li><a href="#">Exercises</a>
                                <ul class="dropdown">
                                    <li><a href="exercise.php?muscle=Chest">Chest</a></li>
                                    <li><a href="exercise.php?muscle=Shoulder">Shoulder</a></li>
                                    <li><a href="exercise.php?muscle=Back">Back</a></li>
                                    <li><a href="exercise.php?muscle=Biceps">Biceps</a></li>
                                    <li><a href="exercise.php?muscle=Triceps">Triceps</a></li>
                                    <li><a href="exercise.php?muscle=Legs">Legs</a></li>
                                    <li><a href="exercise.php?muscle=Cardio">Cardio</a></li>
                                    <li><a href="exercise.php?muscle=Abs"></a>Abs</li>
                                   
                                </ul>
                          </li>
                        <li><a href="./contact.php">Contact</a></li>
                        <li><a href="logout.php">logout</a></li>
                    </ul>
                    </nav>
        <div id="mobile-menu-wrap"></div>
        <div class="canvas-social">
            <a href="#"><i class="fa fa-facebook"></i></a>
            <a href="#"><i class="fa fa-twitter"></i></a>
            <a href="#"><i class="fa fa-youtube-play"></i></a>
            <a href="#"><i class="fa fa-instagram"></i></a>
        </div>
    </div>
    <!-- Offcanvas Menu Section End -->

    <!-- Header Section Begin -->
    <header class="header-section">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-3">
                    <div class="logo">
                        <a href="./index.php">
                            <img src="img/logo.png" alt="">
                        </a>
                    </div>
                </div>
                <div class="col-lg-6">
                    <nav class="nav-menu">
                        <ul>
                            <li class="active"><a href="./index.php">Home</a></li>
                            <li><a href="dietChart.php">Diet Plan</a></li>
                            <li><a href="exercisechart.php">Exercise Chart</a></li>
                            <li><a href="#">Pages</a>
                                <ul class="dropdown">
                                     <li><a href="exercise.php?muscle=Chest">Chest</a></li>
                                    <li><a href="exercise.php?muscle=Shoulder">Shoulder</a></li>
                                    <li><a href="exercise.php?muscle=Back">Back</a></li>
                                    <li><a href="exercise.php?muscle=Biceps">Biceps</a></li>
                                    <li><a href="exercise.php?muscle=Triceps">Triceps</a></li>
                                    <li><a href="exercise.php?muscle=Legs">Legs</a></li>
                                    <li><a href="exercise.php?muscle=Cardio">Cardio</a></li>
                                    <li><a href="exercise.php?muscle=Abs"></a>Abs</li>
                                   
                                </ul>
                            </li>
                            <li><a href="./contact.php">Contact</a></li>
                            <li><a href="logout.php">logout</a></li>
                        </ul>
                    </nav>
                </div>
                <div class="col-lg-3">
                    <div class="top-option">
                        <div class="to-search search-switch">
                            <i class="fa fa-search"></i>
                        </div>
                        <div class="to-social">
                            <a href="#"><i class="fa fa-facebook"></i></a>
                            <a href="#"><i class="fa fa-twitter"></i></a>
                            <a href="#"><i class="fa fa-youtube-play"></i></a>
                            <a href="#"><i class="fa fa-instagram"></i></a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="canvas-open">
                <i class="fa fa-bars"></i>
            </div>
        </div>
    </header>
    <!-- Header End -->
