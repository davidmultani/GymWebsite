<?php
require "connect.php";

// Retrieve registration data from POST request
$dietPlan = strtolower($_POST['dietPlan']);
$name = $_POST['name'];
$description = $_POST['description'];
$servingsize = $_POST['servingsize'];
$protein = $_POST['protein'];
$carbohydrates = $_POST['carbohydrates'];
$fats = $_POST['fats'];
$type = $_POST['type'];

// Check if file is uploaded successfully
if ($_FILES['dish_picture']['error'] === UPLOAD_ERR_OK) {
    // Retrieve information about the uploaded file
    $fileTmpPath = $_FILES['dish_picture']['tmp_name'];
    $fileName = $_FILES['dish_picture']['name'];
    $fileSize = $_FILES['dish_picture']['size'];
    $fileType = $_FILES['dish_picture']['type'];
    
    // Specify the folder where you want to store the uploaded files
    $uploadDirectory = '../img/dietOptions/';

    // Move the uploaded file to the desired destination
    $destPath = $uploadDirectory . $fileName;
    if (!move_uploaded_file($fileTmpPath, $destPath)) {
        // File move failed, handle the error accordingly
        header("Location: adddiet.php?error=" . urlencode("Failed to move uploaded file"));
        exit(); // Terminate script to prevent further execution
    }
} else {
    // File upload failed, handle the error accordingly
    header("Location: adddiet.php?error=" . urlencode("File upload failed: " . $_FILES['dish_picture']['error']));
    exit(); // Terminate script to prevent further execution
}
 
// Sanitize inputs before using in SQL query (to prevent SQL injection)
$name = mysqli_real_escape_string($conn,$name);
$description = mysqli_real_escape_string($conn,$description);
$servingsize = mysqli_real_escape_string($conn,$servingsize);
$protein = mysqli_real_escape_string($conn,$protein);
$carbohydrates = mysqli_real_escape_string($conn,$carbohydrates);
$fats = mysqli_real_escape_string($conn,$fats);
$type = mysqli_real_escape_string($conn,$type);
$destPath = mysqli_real_escape_string($conn, $destPath);

// SQL query to update user info
$sql = "INSERT INTO ".$dietPlan." (name, description, servingsize, protein, carbohydrates, fats, type, photo) 
        values('$name', '$description', '$servingsize', '$protein', '$carbohydrates', '$fats', '$type','$destPath')";

// Execute query
$result = $conn->query($sql);

if ($result === TRUE) {
    // Update successful, redirect to wherever you want
    header("Location: dietPlan.php?dietPlan=$dietPlan&update=success");
    exit(); // Terminate script to prevent further execution
} else {
    // Update failed, redirect back with error message
    header("Location: adddiet.php?error=" . urlencode("Update failed: " . $conn->error));
    exit(); // Terminate script to prevent further execution
}

$conn->close();
?>
