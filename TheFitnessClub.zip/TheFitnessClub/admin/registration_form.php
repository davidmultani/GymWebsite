<?php
require "connect.php";

// Retrieve registration data from POST request
$id = $_GET['id']; 
$name = $_POST['name'];
$email = $_POST['email'];
$phone_no = $_POST['phone_no'];
$username = $_POST['username'];
$password = $_POST['password'];
$encrypt_password = password_hash($password, PASSWORD_DEFAULT);

// Validation for name
if (empty($name)) {
    header("Location: edit_user.php?id=$id&error=" . urlencode("Name is required"));
    exit();
}

// Validation for email
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    header("Location: ../admin_register.php?id=$id&error=" . urlencode("Invalid email format"));
    exit();
}

// Validation for phone number
if (!preg_match('/^\d{10}$/', $phone_no)) {
    header("Location: ../admin_register.php?id=$id&error=" . urlencode("Invalid phone number format"));
    exit();
}

// Validation for username
if (!preg_match('/^[a-zA-Z0-9_]+$/', $username)) {
    header("Location: ../admin_register.php?id=$id&error=" . urlencode("Username can only contain letters, numbers, and underscores"));
    exit();
}

// Validation for password
$min_length = 8;
if (strlen($password) < $min_length || !preg_match('/[A-Z]/', $password) || !preg_match('/[a-z]/', $password) || !preg_match('/[0-9]/', $password) || !preg_match('/[^a-zA-Z0-9]/', $password)) {
    header("Location: ../admin_register.php?id=$id&error=" . urlencode("Password must be at least 8 characters long and contain at least one uppercase letter, one lowercase letter, one number, and one special character"));
    exit();
}

// Check if file is uploaded successfully
if ($_FILES['profile_picture']['error'] === UPLOAD_ERR_OK) {
    // Retrieve information about the uploaded file
    $fileTmpPath = $_FILES['profile_picture']['tmp_name'];
    $fileName = $_FILES['profile_picture']['name'];
    $fileSize = $_FILES['profile_picture']['size'];
    $fileType = $_FILES['profile_picture']['type'];
    
    // Specify the folder where you want to store the uploaded files
    $uploadDirectory = '../img/users_pictures/';

    // Move the uploaded file to the desired destination
    $destPath = $uploadDirectory . $fileName;
    if (!move_uploaded_file($fileTmpPath, $destPath)) {
        // File move failed, handle the error accordingly
        header("Location: ../admin_register.php?id=$id&error=" . urlencode("Failed to move uploaded file"));
        exit(); // Terminate script to prevent further execution
    }
} else {
    // File upload failed, handle the error accordingly
    header("Location: ../admin_register.php?id=$id&error=" . urlencode("File upload failed: " . $_FILES['profile_picture']['error']));
    exit(); // Terminate script to prevent further execution
}

// Sanitize inputs before using in SQL query (to prevent SQL injection)
$id = mysqli_real_escape_string($conn, $id);
$name = mysqli_real_escape_string($conn, $name);
$email = mysqli_real_escape_string($conn, $email);
$phone_no = mysqli_real_escape_string($conn, $phone_no);
$username = mysqli_real_escape_string($conn, $username);
$encrypt_password = mysqli_real_escape_string($conn, $encrypt_password);
$destPath = mysqli_real_escape_string($conn, $destPath);

// SQL query to update user info
$sql = "INSERT INTO admin_info (name,email,phone_no,username,password,photo) VALUES ('$name','$email','$phone_no','$username','$encrypt_password','$destPath')";

// Execute query
$result = $conn->query($sql);

if ($result === TRUE) {
    // Update successful, redirect to wherever you want
    header("Location: index.php?update=success");
    exit(); // Terminate script to prevent further execution
} else {
    // Update failed, redirect back with error message
    header("Location: ../admin_register.php?id=$id&error=" . urlencode("Update failed: " . $conn->error));
    exit(); // Terminate script to prevent further execution
}

$conn->close();
?>
