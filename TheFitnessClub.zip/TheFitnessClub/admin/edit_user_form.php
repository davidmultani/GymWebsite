<?php
require "connect.php";
// Retrieve registration data from POST request
$id = $_GET['id']; 
$name = $_POST['name'];
$email = $_POST['email'];
$phone_no = $_POST['phone_no'];
$weight = $_POST['weight'];
$height = $_POST['height'];
$dob = $_POST['dob'];
$sex=$_POST['sex'];
$level = $_POST['level'];
$activity_level = $_POST['activity_level'];
$target = $_POST['target'];
$membership_end_date = $_POST['membership_end_date'];
$username = $_POST['username'];

// Validation for name
if (empty($name)) {
    header("Location: edit_user.php?id=$id&error=" . urlencode("Name is required"));
    exit();
}

// Validation for email
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    header("Location: edit_user.php?id=$id&error=" . urlencode("Invalid email format"));
    exit();
}

// Validation for phone number
if (!preg_match('/^\d{10}$/', $phone_no)) {
    header("Location: edit_user.php?id=$id&error=" . urlencode("Invalid phone number format"));
    exit();
}

// Validation for username
if (!preg_match('/^[a-zA-Z0-9_]+$/', $username)) {
    header("Location: edit_user.php?id=$id&error=" . urlencode("Username can only contain letters, numbers, and underscores"));
    exit();
}

// Sanitize inputs before using in SQL query (to prevent SQL injection)
$id = mysqli_real_escape_string($conn, $id); 
$name = mysqli_real_escape_string($conn, $name);
$email = mysqli_real_escape_string($conn, $email);
$phone_no = mysqli_real_escape_string($conn, $phone_no);
$weight = mysqli_real_escape_string($conn, $weight);
$height = mysqli_real_escape_string($conn, $height);
$dob = mysqli_real_escape_string($conn, $dob);
$sex = mysqli_real_escape_string($conn, $sex);
$level = mysqli_real_escape_string($conn, $level);
$activity_level = mysqli_real_escape_string($conn, $activity_level);
$target = mysqli_real_escape_string($conn, $target);
$membership_end_date = mysqli_real_escape_string($conn, $membership_end_date);
$username = mysqli_real_escape_string($conn, $username);


// SQL query to update user info
$sql = "UPDATE client_info  SET name='$name', email='$email', phone_no='$phone_no', weight='$weight', height='$height' ,dob='$dob', sex='$sex',
         level='$level' , activity_level='$activity_level', target='$target', membership_end_date='$membership_end_date', username='$username'
        WHERE client_no='$id'";

// Execute query
$result = $conn->query($sql);

if ($result === TRUE) {
    // Update successful, redirect to wherever you want
    header("Location: index.php?update=success");
    exit(); // Terminate script to prevent further execution
} else {
    // Update failed, redirect back with error message
    header("Location: edit_user.php?id=$id&error=" . urlencode("Update failed: " . $conn->error));
    exit(); // Terminate script to prevent further execution
}

$conn->close();
?>
