<?php
require "header.php"
?>  
 <?php
 $id=$_GET['id'];
 $muscle=$_GET['muscle'];
// Prepare and execute SQL query to fetch user info
$sql = "SELECT * FROM $muscle WHERE m_id='$id'";
$result = $conn->query($sql);

if ($result->num_rows == 1) {
    // Fetch user information
    $row = $result->fetch_assoc();
}
?> 
<!-- Breadcrumb Section Begin -->
    <section class="breadcrumb-section set-bg" data-setbg="img/breadcrumb-bg.jpg">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 text-center">
                    <div class="breadcrumb-text">
                        <h2>Edit Exercise</h2>
                        <div class="bt-option">
                            <span>Enter your Information</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Breadcrumb Section End -->

    <!-- Team Section Begin -->
    <section class="team-section team-page spad">
        <div class="container">
            <center>
                <div class="col-lg-6 col-sm-4 mx-auto">
                    <div class="leave-comment">
                        <?php
                        // Check for error message from registration process
                        if (isset($_GET['error'])) {
                            echo "<p style='color: red;' class='error-message'>Registration failed: " . $_GET['error'] . "</p>";
                        }
                        ?>
                        <form action="./edit_exercise_form.php?id=<?php echo $id?>&muscle=<?php echo $muscle?>" method="post" enctype="multipart/form-data">
                        <div class="grid-row">
                                <select name="muscle" required class="mb-4">
                                    <option value="" disabled selected>Select Muscle</option>
                                    <option value="chest" <?php if ($muscle === "chest") echo "selected"; ?>>Chest</option>
                                    <option value="shoulder" <?php if ($muscle === "shoulder") echo "selected"; ?>>Shoulder</option>
                                    <option value="back" <?php if ($muscle === "back") echo "selected"; ?>>Back</option>
                                    <option value="triceps" <?php if ($muscle === "triceps") echo "selected"; ?>>Triceps</option>
                                    <option value="biceps" <?php if ($muscle === "biceps") echo "selected"; ?>>Biceps</option>
                                    <option value="legs" <?php if ($muscle === "legs") echo "selected"; ?>>Legs</option>
                                    <option value="abs" <?php if ($muscle === "abs") echo "selected"; ?>>Abs</option>
                                    <option value="cardio" <?php if ($muscle === "cardio") echo "selected"; ?>>Cardio</option>
                                </select>
                            </div>
                            <input type="text" name="submuscle" placeholder="submuscle" required value="<?php echo $row['submuscle']; ?>">
                            <input type="text" name="exercise_name" placeholder="exercise_name" required value="<?php echo $row['name']; ?>">
                                <input type="file" name="muscle_picture" required/>
                            <input type="submit" value="Add">
                    </form>

                    </div>
                </div>
            </center>
        </div>
    </section>
    <!-- Team Section End -->
    <?php
	require "footer.php"
	?>