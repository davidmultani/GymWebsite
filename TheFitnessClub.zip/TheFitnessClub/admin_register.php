<?php
require "header.php"
?>    
<!-- Breadcrumb Section Begin -->
    <section class="breadcrumb-section set-bg" data-setbg="img/breadcrumb-bg.jpg">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 text-center">
                    <div class="breadcrumb-text">
                        <h2>Admin Register</h2>
                        <div class="bt-option">
                            <span>Enter your Credentials</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Breadcrumb Section End -->

    <!-- Team Section Begin -->
    <section class="team-section team-page spad">
        <div class="container">
            <center>
                <div class="col-lg-6 col-sm-4 mx-auto">
                    <div class="leave-comment">
                        <?php
                        // Check for error message from registration process
                        if (isset($_GET['error'])) {
                            echo "<p style='color: red;' class='error-message'>Registration failed: " . $_GET['error'] . "</p>";
                        }
                        ?>
                        <form action="./admin/registration_form.php" method="post" enctype="multipart/form-data">
                            <input type="text" name="name" placeholder="Name" required>
                            <input type="email" name="email" placeholder="Email" required>
                            <input type="tel" name="phone_no" placeholder="Phone Number" required>
                            <input type="text" name="username" placeholder="Username" required>
                            <input type="password" name="password" placeholder="Password" required>
                                <input type="file" name="profile_picture" required/>
                            <input type="submit" value="Register">
                        </form>
                    </div>
                </div>
            </center>
        </div>
    </section>
    <!-- Team Section End -->
    <?php
	require "footer.php"
	?>