<?php
require "header.php"
?>    
<!-- Breadcrumb Section Begin -->
    <section class="breadcrumb-section set-bg" data-setbg="img/breadcrumb-bg.jpg">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 text-center">
                    <div class="breadcrumb-text">
                        <h2>Reset Password</h2>
                        <div class="bt-option">
                            <span>Enter your Credentials</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Breadcrumb Section End -->

    <!-- Login Section Begin -->
    <section class="team-section team-page spad">
        <div class="container">
            <center>
                <div class="col-lg-6 col-sm-4">
                    <div class="leave-comment">

                        <?php

                        // Check if an error parameter is present in the URL
                        if (isset($_GET['update'])) {
                            if ($_GET['update'] === 'otpexpired') {
                                echo "<p style='color: red; font-size:15px;'>OTP Expired</p>";
                            }
                            elseif($_GET['update'] === 'emailsendfailed'){
                                echo "<p style='color: red; font-size:15px;'>Email Send Failed</p>";
                            }
                            elseif($_GET['update'] === 'emailnotfound'){
                                echo "<p style='color: red; font-size:15px;'>Email Not Found</p>";
                            }
                            else {
                                echo "<p style='color: red; font-size:15px;'>An unknown error occurred</p>";
                            }
                        }
                        ?>
                        
                        <form action="send_otp.php" method="post" onsubmit="return validateForm()">
                            <input type="email" placeholder="Enter the Registered Email" name="email" >
                            <button type="submit" class="primary-btn btn-normal appoinment-btn">Submit</button>
                        </form>
                    </div>
                    <p id="error-message" class="error-message"></p>
                    <div class="p-2">
                    </div>
                </div>
            </center>
        </div>
    </section>
    <!-- Team Section End -->
    <?php
	require "footer.php"
	?>