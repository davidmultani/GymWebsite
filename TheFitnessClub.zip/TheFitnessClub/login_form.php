<?php
require "connect.php";
session_start();
$current_date = date("Y-m-d");
// Retrieve username, password, and answer from POST request
$username = $_POST['username'];
$password = $_POST['password'];
$userAnswer = $_POST['answer'];

// Prepare SQL statement with parameterized query
$sql = "SELECT * FROM client_info WHERE username=?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $username);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    // User found, verify password and answer
    $row = $result->fetch_assoc(); 
    $membership_end = $row['membership_end_date'];
    // Calculate the number of days left of membership
    $days_left = floor((strtotime($membership_end) - strtotime($current_date)) / (60 * 60 * 24));

    if ((password_verify($password, $row['password'])) && ($_SESSION['answer'] == $userAnswer) && ($days_left>=0)) {
        //create a session and store the user information
        $_SESSION['username']=$username;
        // Password and answer are correct, redirect to success page or perform further actions
        header("Location: ./login/index.php");
        exit(); // Terminate script to prevent further execution
    } 
    else {
        if ($days_left < 0) {
            header("Location: ./login.php?error=membershipexpired"); // Change "login.php" to the actual login page URL
            exit();
        } elseif ($_SESSION['answer'] != $userAnswer) {
            // Incorrect answer, redirect back to login page with error message
            header("Location: ./login.php?error=incorrectanswer".$_SESSION['answer']);
            exit();
        } else {
            // Incorrect password, redirect back to login page with error message
            header("Location: ./login.php?error=passwordincorrect");
            exit(); // Terminate script to prevent further execution
        }
    }
} 
else 
{
    // User not found, redirect back to login page with error message
    header("Location: ./login.php?error=Usernotfound");
    exit(); // Terminate script to prevent further execution
}

$stmt->close();
$conn->close();
?>