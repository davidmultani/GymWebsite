<?php
require "header.php"
?>    
    <!-- Breadcrumb Section Begin -->
    <section class="breadcrumb-section set-bg" data-setbg="img/breadcrumb-bg.jpg">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 text-center">
                    <div class="breadcrumb-text">
                        <h2>Contact Us</h2>
                        <div class="bt-option">
                            <a href="./index.php">Home</a>
                            <a href="#">Pages</a>
                            <span>Contact us</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Breadcrumb Section End -->

    <!-- Contact Section Begin -->
    <section class="contact-section spad">
        <div class="container">
            <div class="row">
                <div class="col-lg-6">
                    <div class="section-title contact-title">
                        <span>Contact Us</span>
                        <h2>GET IN TOUCH</h2>
                    </div>
                    <div class="contact-widget">
                        <div class="cw-text">
                            <i class="fa fa-map-marker"></i>
                            <p>Crown Fitness, Near babriek Chownk, Jalandhar, India<br/> 144001</p>
                        </div>
                        <div class="cw-text">
                            <i class="fa fa-mobile"></i>
                            <ul>
                                <li>07986131404</li>
                                <li>9915954008</li>
                            </ul>
                        </div>
                        <div class="cw-text email">
                            <i class="fa fa-envelope"></i>
                            <p>Support.crownfitness@gmail.com</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6">
                <?php 
                       if (isset($_GET['update'])) {
                            if ($_GET['update'] === 'success') {
                                echo "<p style='color: green; font-size:20px;text-align:center;'>Message Sent Successfully.</p>";
                            }
                            if ($_GET['update'] === 'fail') {
                                echo "<p style='color: red; font-size:20px;text-align:center;'>Please try after some time</p>";
                            }
                        }
                             ?>
                    <div class="leave-comment">
                        <form action="contact_form.php" method="post">
                            <input type="text" placeholder="Name" name="name" required>
                            <input type="email" placeholder="Email" name="email" required>
                            <input type="tel" placeholder="Phone Number" name="phone_no" required>
                            <textarea placeholder="Comment" name="comment"></textarea>
                            <button type="submit">Submit</button>
                        </form>
                    </div>
                </div>
            </div>
            <div class="map">
            <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3408.4114191802714!2d75.55287827546495!3d31.320009074306327!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x391a5b9bac671bf9%3A0xd81176e17217171c!2sCROWN%20FITNESS%20GYM!5e0!3m2!1sen!2sin!4v1702893244840!5m2!1sen!2sin" 
                width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
            </div>
        </div>
    </section>
    <!-- Contact Section End -->
    <?php
	require "footer.php"
	?>